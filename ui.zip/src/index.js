import ReactDOM from 'react-dom';
import React from 'react';
import { HashRouter } from 'react-router-dom';
import { Provider } from 'mobx-react';
import promiseFinally from 'promise.prototype.finally';
import * as serviceWorker from './service-worker';

import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import { purple } from '@material-ui/core/colors';

import App from './components/App';

import articlesStore from './stores/articlesStore';
import commentsStore from './stores/commentsStore';
import authStore from './stores/authStore';
import commonStore from './stores/commonStore';
import editorStore from './stores/editorStore';
import userStore from './stores/userStore';
import profileStore from './stores/profileStore';
import feedbackStore from './stores/feedbackStore';
import followStore from './stores/followStore';
import landingPageStore from './stores/landingPageDataStore';
import offerRequestStore from './stores/offerRequestStore';

import 'semantic-ui-css/semantic.min.css'
import "./assets/css/custom.css"

const stores = {
  articlesStore,
  commentsStore,
  authStore,
  commonStore,
  editorStore,
  userStore,
  profileStore,
  feedbackStore,
  followStore,
  landingPageStore,
  offerRequestStore,
};

// For easier debugging
window._____APP_STATE_____ = stores;

promiseFinally.shim();

const theme = createMuiTheme({
  palette: {
    primary: { main: '#5cb85c' }, // Green play nicely together.
    secondary: { main: purple[500] }
  },
  typography: { useNextVariants: true },
});

ReactDOM.render((
  <MuiThemeProvider theme={theme} >
    <Provider {...stores}>
      <HashRouter>
        <App />
      </HashRouter>
    </Provider>
  </MuiThemeProvider>
), document.getElementById('root'));

serviceWorker.register();
