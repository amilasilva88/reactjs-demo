import superagentPromise from 'superagent-promise';
import _superagent from 'superagent';

import commonStore from './stores/commonStore';
import authStore from './stores/authStore';

const superagent = superagentPromise(_superagent, global.Promise);

const UI_ROOT = 'http://localhost:8280/';
const API_ROOT = 'http://localhost:8280/api';
// const UI_ROOT = 'https://xeparcels.com';
// const API_ROOT = 'https://xeparcels.com/app/api';
// const API_ROOT = 'https://conduit.productionready.io/api';

const encode = encodeURIComponent;

const handleErrors = err => {
    if (err && err.response && err.response.status === 401) {
        authStore.logout();
    }
    return err;
};

const responseBody = res => res.body;

const tokenPlugin = req => {
    if (commonStore.token) {
        req.set('authorization', `Bearer ${commonStore.token}`);
    }
};

const requests = {
    del: (url) =>
        superagent
        .del(`${API_ROOT}${url}`)
        .use(tokenPlugin)
        .end(handleErrors)
        .then(responseBody),
    get: url =>
        superagent
        .get(`${API_ROOT}${url}`)
        .use(tokenPlugin)
        .end(handleErrors)
        .then(responseBody),
    put: (url, body) =>
        superagent
        .put(`${API_ROOT}${url}`, body)
        .use(tokenPlugin)
        .end(handleErrors)
        .then(responseBody),
    post: (url, body) =>
        superagent
        .post(`${API_ROOT}${url}`, body)
        .use(tokenPlugin)
        .end(handleErrors)
        .then(responseBody),
    postNoSec: (url, body) =>
        superagent
        .post(`${API_ROOT}${url}`, body)
        .use(tokenPlugin)
        .end(handleErrors)
        .then(responseBody),
    getNoSec: url =>
        superagent
        .get(`${API_ROOT}${url}`)
        .end(handleErrors)
        .then(responseBody),
    login: (url, body) =>
        superagent
        .post(`${API_ROOT}${url}`, body)
        .end(handleErrors)
        .then(responseBody),
    register: (url, body) =>
        superagent
        .post(`${API_ROOT}${url}`, body)
        .end(handleErrors)
        .then(responseBody),
};

const Auth = {
    current: () =>
        requests.get('/currentUser'),
    login: (email, password) =>
        requests.login('/login', { email, password }),
    logout: () =>
        requests.get('/logout'),
    register: (displayName, email, password) =>
        requests.register('/sign-up', { displayName, email, password })
};

const Tags = {
    getAll: () => requests.get('/tags')
};

const limit = (count, p) => `size=${count}&page=${p}`;
const omitSlug = article => Object.assign({}, article, { slug: undefined })

const Articles = {
    all: (page, lim = 20) =>
        requests.getNoSec(`/articles?${limit(lim, page)}`),
    search: (predicate, page, lim = 20) =>
        requests.postNoSec(`/articles/search?${limit(lim, page)}`, predicate),
    // byAuthor: (author, page, query) =>
    //   requests.get(`/articles?author=${encode(author)}&${limit(5, page)}`),
    // byTag: (tag, page, lim = 20) =>
    //   requests.get(`/articles?tag=${encode(tag)}&${limit(lim, page)}`),
    del: slug =>
        requests.del(`/articles/${slug}`),
    favorite: slug =>
        requests.post(`/articles/${slug}/favorite`),
    favoritedBy: (author, page) =>
        requests.get(`/articles?favorited=${encode(author)}&${limit(5, page)}`),
    feed: () =>
        requests.get('/articles/feed?limit=10&offset=0'),
    get: slug =>
        requests.getNoSec(`/articles/${slug}`),
    unfavorite: slug =>
        requests.del(`/articles/${slug}/favorite`),
    update: article =>
        requests.put(`/articles/${article.slug}`, { article: omitSlug(article) }),
    create: article =>
        requests.post('/articles', article)
};

const ViewCounter = {
    plusOne: entityId =>
        requests.get(`/viewCounter/plusOne/${entityId}`),
    get: entityId =>
        requests.get(`/viewCounter/${entityId}`)
};

const Offers = {
    create: (offer) =>
        requests.post(`/offerRequests`, offer),
    delete: (offerId) =>
        requests.del(`/offerRequests/${offerId}`),
    forUser: entityId =>
        requests.get(`/offerRequests/user/${entityId}`),
    forArticle: entityId =>
        requests.get(`/offerRequests/article/${entityId}`),
    userOffersForArticle: entityId =>
        requests.get(`/offerRequests/userOffers/article/${entityId}`),
    userOffersForArticle: entityId =>
        requests.get(`/offerRequests/userOffers/article/${entityId}`),
    findAcceptedOffer: entiryId =>
        requests.get(`/offerRequests/findAcceptedOffer/${entiryId}`),
    acceptOffer: (offerId) =>
        requests.put(`/offerRequests/accepted/${offerId}`),
    confirmOffer: (offerId) =>
        requests.put(`/offerRequests/confirmed/${offerId}`)

};

const Comments = {
    create: (comment) =>
        requests.post(`/comments`, comment),
    delete: (commentId) =>
        requests.del(`/comments/${commentId}`),
    forArticle: entityId =>
        requests.get(`/comments/article/${entityId}`),
    forProfile: entityId =>
        requests.get(`/comments/profile/${entityId}`)
};


const Profile = {
    get: username =>
        requests.get(`/profiles/${encodeURI(username)}/`),
    follow: (username, follower) =>
        requests.put(`/profiles/${encodeURI(username)}/follow`, follower),
    unfollow: (username, follower) =>
        requests.put(`/profiles/${encodeURI(username)}/unfollow`, follower),
    save: (username, user) =>
        requests.put(`/profiles/${encodeURI(username)}/`, user)
};

const Feedback = {
    forArticle: entityId =>
        requests.get(`/feedbacks/article/${entityId}`),
    forUser: entityId =>
        requests.get(`/feedbacks/user/${entityId}`),
    get: id =>
        requests.get(`/feedbacks/${id}/`),
    save: (id, feedback) =>
        requests.put(`/feedbacks/${id}/`, feedback)
}

const CountryData = {
    get: () =>
        requests.get(`/countries`),
    getCities: country =>
        requests.get(`/countries/${country}/cities`)
};

const LandingSummary = {
    getCountrySummary: () =>
        requests.get(`/landingPage/countrySummary`),
    getCountryMapSummary: () =>
        requests.get(`/landingPage/countryMapSummary`)
};

export default {
    UI_ROOT,
    Articles,
    ViewCounter,
    Offers,
    Auth,
    Comments,
    Profile,
    Tags,
    Feedback,
    CountryData,
    LandingSummary,
};