// Flag for enabling cache in production
var doCache = true;

var CACHE_NAME = 'xeparcels-app-cache';

// Delete old caches
self.addEventListener('activate', event => {
  const currentCachelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys()
      .then(keyList =>
        Promise.all(keyList.map(key => {
          if (!currentCachelist.includes(key)) {
            return caches.delete(key);
          }
        }))
      )
  );
});

// This triggers when user starts the app
self.addEventListener('install', function (event) {
  if (doCache) {
    event.waitUntil(
      caches.open(CACHE_NAME)
        .then(function (cache) {
          fetch('assets/manifest.json')
            .then(response => {
              response.json();
            })
            .then(assets => {
              // We will cache initial page and the index.bundle.js
              // We could also cache assets like CSS and images
              const urlsToCache = [
                '/',
                '/assets/css/main.css',
                '/assets/custom.css',
                '/index.bundle.js',
                '/assets/img/country-imgs/Australia.jpg',
                '/assets/img/country-imgs/Canada.jpg',
                '/assets/img/country-imgs/France.jpg',
                '/assets/img/country-imgs/Ireland.jpg',
                '/assets/img/country-imgs/Italy.jpg',
                '/assets/img/country-imgs/New Zealand.jpg',
                '/assets/img/country-imgs/Singapore.jpg',
                '/assets/img/country-imgs/Sri Lanka.jpg',
                '/assets/img/country-imgs/Switzerland.jpg',
                '/assets/img/country-imgs/UK.jpg',
                '/assets/img/country-imgs/USA.jpg'
                // assets['index.bundle.js']
              ];
              cache.addAll(urlsToCache);
            })
        })
    );
  }
});
// Here we intercept request and serve up the matching files
self.addEventListener('fetch', function (event) {
  if (doCache) {
    event.respondWith(
      caches.match(event.request).then(function (response) {
        // Cache hit - return response
        if (response) {
          return response;
        }
        return fetch(event.request);
      })
    );
  }
});