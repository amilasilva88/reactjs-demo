import _ from 'lodash';

const hasOwnProperty = Object.prototype.hasOwnProperty;

const validator = {
    validateEmail: (mail) => {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return !re.test(String(mail).toLowerCase());
    },
    isNumber: (value) => {
        return _.isNumber(value);
    },
    isEmpty: (obj) => {

        return _.isEmpty(obj);
        // // Speed up calls to hasOwnProperty

        // // null and undefined are "empty"
        // if (obj == null) return true;

        // // Assume if it has a length property with a non-zero value
        // // that that property is correct.
        // if (obj.length > 0) return false;
        // if (obj.length === 0) return true;

        // // If it isn't an object at this point
        // // it is empty, but it can't be anything *but* empty
        // // Is it empty?  Depends on your application.
        // if (typeof obj !== "object") return true;

        // // Otherwise, does it have any properties of its own?
        // // Note that this doesn't handle
        // // toString and valueOf enumeration bugs in IE < 9
        // for (var key in obj) {
        //     if (hasOwnProperty.call(obj, key)) return false;
        // }

        // return true;
    },
    validatePrice: (price) => {
        return /^(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/.test(price);
    },
    validLength: (value, size) => {
        return (value && value.trim().length <= size);
    }

}

export default validator;