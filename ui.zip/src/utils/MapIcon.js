import L from 'leaflet';

const blueMarker = new L.Icon({
    iconUrl: require('../assets/img/marker-Flag-3.png'),
    iconRetinaUrl: require('../assets/img/marker-Flag-3.png'),
    iconSize:     [38, 50], // size of the icon
    shadowSize:   [50, 64], // size of the shadow
    // point of the icon which will correspond to marker's location
    shadowAnchor: [4, 62],  // the same for the shadow
    // point from which the popup should open relative to the iconAnchor
    //className: 'leaflet-div-icon'
});

export { blueMarker };