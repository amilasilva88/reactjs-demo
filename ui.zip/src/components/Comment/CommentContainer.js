import React from 'react';
import { Link } from 'react-router-dom';
import { inject, observer } from 'mobx-react';

import CommentInput from './CommentInput';
import CommentList from './CommentList';
import RedError from '../RedError';

import {
  Divider,
} from 'semantic-ui-react';


@inject('commentsStore')
@observer
class CommentContainer extends React.Component {

  entityId = "";
  entityType = "";

  componentWillMount() {
    this.entityType = this.props.entityType;
    this.entityId = this.props.entityId;
    if (this.entityId) {
      this.props.commentsStore.loadComments(this.entityType, this.entityId);
    }
  }

  componentDidMount() {

  }

  componentWillUnmount() {
    this.props.commentsStore.reset();
  }

  handleDeleteComment = (entityType, entityId, id) => {
    this.props.commentsStore.deleteComment(entityType, entityId, id);
  };


  render() {
    const { currentUser, entityType, entityId, commentErrors } = this.props;

    if (!currentUser) return "";

    if (this.entityId !== entityId) {
      this.props.commentsStore.loadComments(entityType, entityId);
      this.entityType = entityType;
      this.entityId = entityId;
    }
    const comments = this.props.commentsStore.getComments(entityType, entityId);
    if (!comments) return <RedError message="unable to load the comments" />;

    if (currentUser) {
      return (
        <div className="col-xs-12">
          <div>
            <list-errors errors={commentErrors} />
            <CommentInput entityType={entityType} entityId={entityId} currentUser={currentUser} />
          </div>

          <Divider inverted />

          <CommentList
            entityType={entityType}
            entityId={entityId}
            comments={comments}
            currentUser={currentUser}
            onDelete={this.handleDeleteComment}
          />
        </div>
      );
    } else {
      return (
        <div className="col-xs-12">
          <p>
            <Link to="/login">Sign in</Link>
            &nbsp;or&nbsp;
          <Link to="/register">sign up</Link>
            &nbsp;to add comments on this article.
        </p>

          <Divider inverted />

          <CommentList
            entityType={entityType}
            entityId={entityId}
            comments={comments}
            currentUser={currentUser}
            onDelete={this.handleDeleteComment}
          />
        </div>
      );
    }
  }
}

export default CommentContainer;
