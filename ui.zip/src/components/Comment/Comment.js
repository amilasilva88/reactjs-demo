import React from 'react';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import Avatar from 'react-avatar';

import DeleteButton from './DeleteButton';

const Comment = props => {
  const {comment, entityType, entityId} = props;
  const show = props.currentUser && props.currentUser.email === comment.owner.email;

  return (
    <div className="card">
      <div className="card-block">
        <p className="card-text">{comment.comment}</p>
      </div>
      <div className="card-footer">
        <div className="article-meta">
          <Link to={`/@${comment.owner.userId}`}>
            <Avatar name={comment.owner.displayName}
              size={25}
              round={true}
              textSizeRatio={2}
              src={comment.owner.avatarPath} />
          </Link>

          <div className="info">
            <Link to={`/@${comment.owner.userId}`} className="author">
              {comment.owner.displayName}
            </Link>
            <span className="date">
              <Moment fromNow>{new Date(comment.createdDateTime).toISOString()}</Moment>
            </span>
          </div>

          <DeleteButton
            entityType={entityType}
            entityId={entityId}
            show={show}
            slug={props.slug}
            commentId={comment.id}
            onDelete={props.onDelete}
          />
        </div>
      </div>
    </div>
  );
};

export default Comment;
