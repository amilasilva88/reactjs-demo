import React from 'react';
import { inject } from 'mobx-react';
import Avatar from 'react-avatar';

import validator from '../../utils/Validation';

@inject('commentsStore')
export default class CommentInput extends React.Component {

  constructor(props) {
    super();
    this.state = {
      body: ''
    };

    this.handleBodyChange = ev => {
      this.setState({ body: ev.target.value });
    };

    this.createComment = ev => {
      ev.preventDefault();

      const { entityType, entityId, commentsStore } = this.props;
      switch (entityType) {
        case 'user':
          commentsStore.comment['profileId'] = entityId;
          break;
        case 'article':
          commentsStore.comment['articleId'] = entityId;
          break;
      }
      commentsStore.comment['comment'] = this.state.body;

     
      if(commentsStore.validite()) {
        return;
      }
     
      commentsStore.createComment(entityType, entityId)
        .then(() => this.setState({ body: '' }));
    };
  }

  render() {
    const { isCreatingComment, errors } = this.props.commentsStore;
    const { currentUser } = this.props;

    return (
      <form className="card comment-form" onSubmit={this.createComment}>
        <div className="card-block">
          <textarea className="form-control"
            placeholder="Write a comment..."
            value={this.state.body}
            disabled={isCreatingComment}
            onChange={this.handleBodyChange}
            name="comment"
            error={errors['comment']}
            rows="3"
          />
        </div>
        <div className="card-footer">
          <div className="article-meta">
            <Avatar name={currentUser.displayName}
              size={25}
              round={true}
              textSizeRatio={2}
              src={currentUser.avatarPath} />

            <div className="info">
              <div className="author">
                {currentUser.displayName}
              </div>
            </div>

            <button
              className="btn btn-sm btn-primary"
              type="submit">
              Post Comment
            </button>
          </div>
        </div>
      </form>
    );
  }
}
