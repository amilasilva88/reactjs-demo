import React from 'react';
import { observer } from 'mobx-react';

import Comment from './Comment';

const CommentList = observer(props => {
  return (
    <div>
      {
        props.comments.map(comment => {
          return (
            <Comment
              entityType={props.entityType}
              entityId={props.entityId}
              comment={comment}
              currentUser={props.currentUser}
              slug={props.slug}
              id={comment.id}
              key={comment.id}
              onDelete={props.onDelete}
            />
          );
        })
      }
    </div>
  );
});

export default CommentList;
