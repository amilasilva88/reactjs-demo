import React from 'react';

const DeleteButton = props => {
  
  const {entityType, entityId} = props;
  const handleClick = () => props.onDelete(entityType, entityId, props.commentId);

  if (props.show) {
    return (
      <span className="mod-options">
        <i className="far fa-trash-alt" onClick={handleClick}></i>
      </span>
    );
  }
  return null;
};

export default DeleteButton;
