import _ from 'lodash'
import React from 'react';
import { Link, withRouter } from 'react-router-dom';
import { inject, observer } from 'mobx-react';
import Avatar from 'react-avatar';
import { Search } from 'semantic-ui-react';

import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import InputBase from '@material-ui/core/InputBase';
import Badge from '@material-ui/core/Badge';
import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';
import { fade } from '@material-ui/core/styles/colorManipulator';
import { withStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import Button from '@material-ui/core/Button';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';

import MenuIcon from '@material-ui/icons/Menu';

import {
  MoreVert as MoreIcon,
  MailIcon,
  MoveToInbox as InboxIcon,
  HomeOutlined as HomeIcon,
  NoteAddOutlined as NoteAddIcon,
  PowerSettingsNewOutlined as LoginIcon,
  SearchIcon,
  AccountCircle,
  AccountCircleOutlined as SignUpIcon,
  NotificationsIcon,
  PowerSettingsNew
} from '@material-ui/icons';


const styles = theme => ({
  root: {
    width: '100%',
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  title: {
    display: 'block',
    fontWeight: 200,
    fontFamily: 'Audiowide',
    marginLeft: theme.spacing(2),
    [theme.breakpoints.up('sm')]: {
      display: 'block',
      marginLeft: theme.spacing(2),
    },
  },
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: fade(theme.palette.common.white, 0.25),
    },
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(3),
      width: 'auto',
    },
  },
  searchIcon: {
    width: theme.spacing(9),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputRoot: {
    color: 'inherit',
    width: '100%',
  },
  inputInput: {
    paddingTop: theme.spacing(1),
    paddingRight: theme.spacing(1),
    paddingBottom: theme.spacing(1),
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('md')]: {
      width: 200,
    },
  },
  sectionDesktop: {
    display: 'none',
    [theme.breakpoints.up('md')]: {
      display: 'flex',
    },
  },
  sectionMobile: {
    display: 'flex',
    [theme.breakpoints.up('md')]: {
      display: 'none',
    },
  },
  list: {
    width: 250,
  },
  fullList: {
    width: 'auto',
  },
  navBar: {
    backgroundColor: "#5cb85c"
  }
});

const VisitorView = props => {
  if (!props.currentUser) {
    return (
      <React.Fragment>
        <Button color="inherit" onClick={props.gotoHome} >
          <HomeIcon />
        </Button>
        <Button color="inherit" onClick={props.addNewPost} >
          <NoteAddIcon />&nbsp; New Post
        </Button>
        <Button color="inherit" onClick={props.signIn} >
          <LoginIcon />&nbsp;Sign in
        </Button>
        <Button color="inherit" onClick={props.signUp} >
          <SignUpIcon />&nbsp;Sign up
        </Button>
      </React.Fragment>
    );
  }
  return null;
};

const VisitorMobileMenu = props => {
  if (!props.currentUser) {
    return (
      <React.Fragment>
        <MenuItem onClick={props.gotoHome}><HomeIcon />&nbsp;Home</MenuItem>
        <MenuItem onClick={props.addNewPost}><NoteAddIcon />&nbsp;New Post</MenuItem>
        <MenuItem onClick={props.signIn}><LoginIcon />&nbsp;Sign in</MenuItem>
        <MenuItem onClick={props.signUp}><SignUpIcon />&nbsp;Sign up</MenuItem>
      </React.Fragment>
    );
  }
  return null;
};

const LoggedInView = props => {

  if (props.currentUser) {
    return (
      <React.Fragment>
        <Button color="inherit" onClick={props.gotoHome} >
          <HomeIcon />
        </Button>
        <Button color="inherit" onClick={props.addNewPost} >
          <NoteAddIcon />&nbsp;New Post
        </Button>

        <IconButton
          aria-owns={props.isMenuOpen ? 'material-appbar' : undefined}
          aria-haspopup="true"
          onClick={props.handleProfileMenuOpen}
          color="inherit">
          <Avatar name={props.currentUser.displayName}
            round={true}
            size={25}
            textSizeRatio={2}
            src={props.currentUser.avatarPath} />
          <Typography component="p" color="inherit">
            &nbsp;{props.currentUser.displayName}
          </Typography>

        </IconButton>
      </React.Fragment>
    );
  }
  return null;
};

const LoggedInMobileMenu = props => {

  if (props.currentUser) {
    return (
      <React.Fragment>
        <MenuItem onClick={props.gotoHome}><HomeIcon />&nbsp;Home</MenuItem>
        <MenuItem onClick={props.addNewPost}><NoteAddIcon />&nbsp;New Post</MenuItem>
        <MenuItem onClick={props.openProfile}><AccountCircle />&nbsp;Profile</MenuItem>
      </React.Fragment>
    );
  }
  return null;
};

@inject('authStore', 'userStore', 'commonStore', 'articlesStore')
@withRouter
@observer
class Header extends React.Component {

  state = {
    anchorEl: null,
    mobileMoreAnchorEl: null,
    left: false,
  };

  Header() {
    this.setState({
      isLoading: false,
      value: ''
    });
  }

  componentWillMount() {
    this.resetComponent()
  }

  resetComponent = () => this.setState({ isLoading: false, value: '' })


  handleSearchChange = (e, { value }) => {
    this.setState({
      isLoading: true,
      value: value
    }, () => {
      const predicate = {
        searchText: this.state.value
      };
      if (value.length >= 3 || value.length < 1) {
        this.props.articlesStore.setPredicate(predicate);
        this.props.articlesStore.loadArticles();
      }
    });

    setTimeout(() => {
      if (this.state.value.length < 1) return this.resetComponent()

      const re = new RegExp(_.escapeRegExp(this.state.value), 'i')

      this.setState({
        isLoading: false
      })
    }, 300)
  };

  handleProfileMenuOpen = event => {
    this.setState({ anchorEl: event.currentTarget });
  };

  handleMenuClose = () => {
    this.setState({ anchorEl: null });
    this.handleMobileMenuClose();
  };

  handleMobileMenuOpen = event => {
    this.setState({ mobileMoreAnchorEl: event.currentTarget });
  };

  handleMobileMenuClose = () => {
    this.setState({ mobileMoreAnchorEl: null });
  };

  toggleDrawer = (side, open) => () => {
    this.setState({
      [side]: open,
    });
  };

  gotoHome = () => {
    const { history } = this.props;
    history.push(`/`);
  };

  addNewPost = () => {
    const { history } = this.props;
    history.push(`/article/new`);
  };

  signIn = () => {
    const { history } = this.props;
    history.push(`/login`);
  };

  signUp = () => {
    const { history } = this.props;
    history.push(`/register`);
  };

  handleLogout = ev => {
    ev.preventDefault();
    this.props.authStore.logout();
  };

  openProfile = () => {
    const { history } = this.props;
    history.push(`/@${this.props.userStore.currentUser.userId}`);
  };


  render() {
    const { anchorEl, mobileMoreAnchorEl } = this.state;
    const { classes } = this.props;
    const isMenuOpen = Boolean(anchorEl);
    const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
    const { currentUser } = this.props.userStore;

    const renderMenu = (
      <Menu
        anchorEl={anchorEl}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        open={isMenuOpen}
        onClose={this.handleMenuClose}
      >
        <MenuItem onClick={this.openProfile}><AccountCircle />&nbsp;Profile</MenuItem>
        <MenuItem onClick={this.handleLogout}><PowerSettingsNew />&nbsp;Logout</MenuItem>
      </Menu>
    );

    const renderMobileMenu = (
      <Menu
        anchorEl={mobileMoreAnchorEl}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        open={isMobileMenuOpen}
        onClose={this.handleMenuClose}
      >
        <VisitorMobileMenu currentUser={currentUser} gotoHome={this.gotoHome} addNewPost={this.addNewPost} signIn={this.signIn} signUp={this.signUp} />
        <LoggedInMobileMenu currentUser={currentUser} gotoHome={this.gotoHome} addNewPost={this.addNewPost} isMenuOpen={this.isMenuOpen} openProfile={this.openProfile} />
      </Menu>
    );

    const sideList = (
      <div className={classes.list}>
        <List>
          {['Inbox', 'Starred', 'Send email', 'Drafts'].map((text, index) => (
            <ListItem button key={text}>
              <ListItemIcon>{index % 2 === 0 ? <InboxIcon /> : <MailIcon />}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItem>
          ))}
        </List>
        <Divider />
        <List>
          {['All mail', 'Trash', 'Spam'].map((text, index) => (
            <ListItem button key={text}>
              <ListItemIcon>{index % 2 === 0 ? <InboxIcon /> : <MailIcon />}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItem>
          ))}
        </List>
      </div>
    );

    return (
      <React.Fragment>
        <Drawer open={this.state.left} onClose={this.toggleDrawer('left', false)}>
          <div
            tabIndex={0}
            role="button"
            onClick={this.toggleDrawer('left', false)}
            onKeyDown={this.toggleDrawer('left', false)}
          >
            {sideList}
          </div>
        </Drawer>
        <div className={classes.root}>
          <AppBar position="static" className={classes.navBar}>
            <Toolbar>
              <img src="./assets/favicons/favicon-32x32.png" onClick={this.gotoHome}/>
              <Typography className={classes.title} variant="h6" color="inherit" noWrap onClick={this.gotoHome}>
                {this.props.commonStore.appName}
              </Typography>
              <div className={classes.grow} />
              <div className={classes.sectionDesktop}>
                <VisitorView currentUser={currentUser} gotoHome={this.gotoHome} addNewPost={this.addNewPost} signIn={this.signIn} signUp={this.signUp} />
                <LoggedInView currentUser={currentUser} gotoHome={this.gotoHome} addNewPost={this.addNewPost} isMenuOpen={this.isMenuOpen} handleProfileMenuOpen={this.handleProfileMenuOpen} />
              </div>
              <div className={classes.sectionMobile}>
                <IconButton aria-haspopup="true" onClick={this.handleMobileMenuOpen} color="inherit">
                  <MoreIcon />
                </IconButton>
              </div>
            </Toolbar>
          </AppBar>
          {renderMenu}
          {renderMobileMenu}
        </div>
      </React.Fragment>

    );
  }
}

export default withStyles(styles)(Header);
