import React from 'react';
import { observer } from 'mobx-react';
import { Link } from 'react-router-dom';
import Avatar from 'react-avatar';
import Moment from 'react-moment';

import Feedback from '../util/Feedback';


import {
    Grid
} from 'semantic-ui-react'

import {
    WhatsappIcon,
    EmailIcon,
} from 'react-share';

import WhatsappMsgButton from '../messaging/WhatsappMsgButton';
import EmailMsgButton from '../messaging/EmailMsgButton';


@observer
class ArticleOwner extends React.Component {

    showWhatsAppLink = (owner, msgTitle, msg) => {
        return (owner.phoneNo) ?
            <WhatsappMsgButton
                url=""
                phone={owner.phoneNo}
                title={msgTitle}
                separator=" "
                className="share-icon">
                <WhatsappIcon size={32} round />
            </WhatsappMsgButton>
            : null;
    }

    showEmailLink = (owner, msgTitle, msg) => {
        return (owner.email) ?
            <EmailMsgButton
                to={owner.email}
                url={msg}
                subject={msgTitle}
                body={msg}
                className="share-icon">
                <EmailIcon size={32} round />
            </EmailMsgButton>
            : null;
    }

    render() {
        const owner = this.props.owner;
        const msgTitle = this.props.msgTitle;
        const msg = this.props.msg;

        return (
            <div>
                <div className="article-owner">
                    <Link to={`/@${owner.userId}`}>
                        <Avatar name={owner.displayName}
                            round={true}
                            size={75}
                            textSizeRatio={2}
                            src={owner.avatarPath} />
                    </Link>

                    <div className="ownerInfo">
                        <Link to={`/@${owner.userId}`} className="author">
                            {owner.displayName}
                        </Link>
                        <span className="date">
                            Joined <Moment fromNow>{new Date(owner.since).toISOString()}</Moment>
                        </span>
                        <Feedback entityType='user' enityId={owner.userId} />
                    </div>
                </div>
                <div className="owner-feedback">
                    <Grid.Row className="shareButtons-left">
                        {this.showWhatsAppLink(owner, msgTitle, msg)}
                        {this.showEmailLink(owner, msgTitle, msg)}
                    </Grid.Row>
                </div>
            </div>
        );
    }
}

export default ArticleOwner;
