import React from 'react';
import Moment from 'react-moment';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { inject, observer } from 'mobx-react';
import Avatar from 'react-avatar';
import LinesEllipsis from 'react-lines-ellipsis'
import Rating from 'material-ui-rating';

import {
  Paper,
  InputBase,
  Divider,
  IconButton,
  CardActionArea,
  Card,
  CardHeader,
  CardMedia,
  CardContent,
  withStyles,
  List,
  ListItem,
  Typography,
  ListItemText,
} from '@material-ui/core';

import {
  MenuIcon,
  SearchIcon,
  DirectionsIcon,
  Payment as PaymentIcon,
  BeachAccess as BeachAccessIcon,
  BusinessCenter as BusinessCenterIcon,
  FlightTakeoff as FlightTakeoffIcon,
  FlightLand as FlightLandIcon,
  DateRange as DateRangeIcon
} from '@material-ui/icons';


import red from '@material-ui/core/colors/red';

const FAVORITED_CLASS = 'btn btn-sm btn-primary';
const NOT_FAVORITED_CLASS = 'btn btn-sm btn-outline-primary';

const styles = theme => ({
  root: {
    flexGrow: 1,
  },
  media: {
    height: 0,
    paddingTop: '5%', // 16:9
  },
  actions: {
    display: 'flex',
  },
  expand: {
    transform: 'rotate(0deg)',
    transition: theme.transitions.create('transform', {
      duration: theme.transitions.duration.shortest,
    }),
    marginLeft: 'auto',
    [theme.breakpoints.up('sm')]: {
      marginRight: -8,
    },
  },
  expandOpen: {
    transform: 'rotate(180deg)',
  },
  avatar: {
    backgroundColor: red[500],
  },
  cardContent: {
    paddingLeft: 0,
    paddingRight: 0,
    paddingBottom: 0,
    paddingTop: 0
  },
  topDescription: {
    paddingLeft: 16,
    paddingRight: 16,
    fontWeight: 600
  },
  iconWrapper: {
    padding: 16,
    display: 'flex',
    position: 'relative',
    overflow: 'hidden',
    alignItems: 'center',
    flexShrink: 0,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.1)'
  },
  listItemFirst: {
    paddingRight: 0,
    paddingLeft: 0,
    paddingTop: 0,
    paddingBottom: 0,
    borderBottom: '1px solid rgba(0, 0, 0, 0.12)',
    borderTop: '1px solid rgba(0, 0, 0, 0.12)'
  },
  listItem: {
    paddingRight: 0,
    paddingLeft: 0,
    paddingTop: 0,
    paddingBottom: 0,
    borderBottom: '1px solid rgba(0, 0, 0, 0.12)'
  },
  listItemLast: {
    paddingRight: 0,
    paddingLeft: 0,
    paddingTop: 0,
    paddingBottom: 0
  },
  svgIcon: {
    fontSize: 14
  },
  list: {
    paddingBottom: 0,
    paddingTop: 0
  },
  iconButton: {
    width: 20,
    height: 20,
    padding: 5
  },
  icon: {
    width: 18,
    height: 18
  },
  titleText: {
    display: 'block',
    width: '100%'
  },
  ratingWrapper: {
    display: 'block',
    width: '100%',
    marginTop: -8,
    marginLeft: -4
  },
  listItemText: {
    paddingLeft: 10,
    paddingRight: 10,
    marginTop: 0,
    marginBottom: 0
  }
});


@inject('articlesStore')
@withRouter
@observer
class ArticlePreview extends React.Component {

  handleClickFavorite = ev => {
    ev.preventDefault();
    const { articlesStore, article } = this.props;
    if (article.favorited) {
      articlesStore.unmakeFavorite(article.slug);
    } else {
      articlesStore.makeFavorite(article.slug);
    }
  };

  capitalize = s => {
    return (s) ?
      s.toLowerCase().replace(/\b./g, function (a) { return a.toUpperCase(); })
      : s;
  };

  sanitize = val => {
    return (val === undefined || val == null || val.length <= 0) ? "" : val;
  };

  numberFormat = n => {
    return (n) ? n.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,') : n;
  };

  viewDetail = (id) => {
    const { history } = this.props;
    history.push(`/article/${id}`);
  };

  getListText = (text) => {
    return <LinesEllipsis
        text={text}
        maxLine='2'
        ellipsis='...'
        trimRight
        basedOn='letters'
    />
  };

  render() {
    const { article, classes } = this.props;
    const favoriteButtonClass = article.favorited ? FAVORITED_CLASS : NOT_FAVORITED_CLASS;

    const priceTag = (this.numberFormat(article.price) > 0)
      ? ' (' + this.sanitize(article.currencyCode) + ' ' + this.numberFormat(article.price) + ')'
      : '';

    return (
      <React.Fragment>
        <Card className={classes.card}
          onClick={() => this.viewDetail(article.id)}
          raised={true}
        >
          <CardActionArea>
            <CardHeader
              avatar={<Avatar name={article.owner.displayName}
                size={35}
                round={true}
                textSizeRatio={2}
                src={article.owner.avatarPath} />
              }
              title={
                <span>
                  <span className={classes.titleText}>{article.owner.displayName}</span>
                </span>
              }
              subheader={<Moment toNow>{article.pickupDateTime}</Moment>}
              action={
                <IconButton>
                  {(article.transportType === 'local') ? <i className="fas fa-truck"></i> : <i className="fas fa-plane-departure"></i>}
                </IconButton>
              }
              className="article-preview-header"
            />
            <CardContent className={classes.cardContent}>
              <List className={`${classes.root} ${classes.list}`}>
                <ListItem className={classes.listItemFirst}>
                  <div className={classes.iconWrapper}>
                    <BusinessCenterIcon className={classes.svgIcon} />
                  </div>
                  <ListItemText
                      className={classes.listItemText}
                      primary={this.getListText(this.capitalize(article.deliveryItem) + ' ' + priceTag)}
                  />
                </ListItem>
                <ListItem className={classes.listItem}>
                  <div className={classes.iconWrapper}>
                    <FlightTakeoffIcon className={classes.svgIcon} />
                  </div>
                  <ListItemText
                      className={classes.listItemText}
                      primary={this.getListText(this.capitalize(article.pickupLocation))}
                  />
                </ListItem>
                <ListItem className={classes.listItem}>
                  <div className={classes.iconWrapper}>
                    <DateRangeIcon className={classes.svgIcon} />
                  </div>
                  <ListItemText className={classes.listItemText}
                    primary={this.getListText((<Moment format="lll">{new Date(article.pickupDateTime).toISOString()}</Moment>))}
                  />
                </ListItem>
                <ListItem className={classes.listItem}>
                  <div className={classes.iconWrapper}>
                    <FlightLandIcon className={classes.svgIcon} />
                  </div>
                  <ListItemText
                      className={classes.listItemText}
                      primary={this.getListText(this.capitalize(article.dropoffLocation))} />
                </ListItem>
                <ListItem className={classes.listItemLast}>
                  <div className={classes.iconWrapper}>
                    <BeachAccessIcon className={classes.svgIcon} />
                  </div>
                  <ListItemText
                      className={classes.listItemText}
                      primary={this.getListText(this.capitalize(article.serviceMode))} />
                </ListItem>
              </List>
            </CardContent>
          </CardActionArea>
        </Card>
      </React.Fragment>
    );
  }
}


ArticlePreview.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(ArticlePreview);
