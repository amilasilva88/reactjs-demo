import React from 'react';
import { inject, observer } from 'mobx-react';

import {
  withStyles,
} from '@material-ui/core';


import SearchField from './SearchField';
import SearchResult from './SearchResult';

const styles = theme => ({
  root: {
    flexGrow: 1,
  },
  card: {
    maxWidth: 250,
    maxHeight: 350,
    cardStyle: 5
  },
  cardStyle: {
    margin: '5px',
    padding: '5px',
    borderRadius: '3px'
  },

});


@inject('articlesStore')
@observer
class ArticleList extends React.Component {

  componentWillMount() {
    this.props.articlesStore.loadArticles();
  }

  render() {

    return (
      <React.Fragment>
        <SearchField />
        <SearchResult />
      </React.Fragment>
    );
  };

}

export default withStyles(styles)(ArticleList);
