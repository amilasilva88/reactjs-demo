import React from 'react';
import { inject, observer } from 'mobx-react';
import { withStyles } from '@material-ui/core/styles';

import {
    Search as SearchIcon,
} from '@material-ui/icons';

import {
    Button,
    Checkbox,
    Grid,
    FormControlLabel,
    TextField,
} from '@material-ui/core';



const styles = theme => ({
    root: {
        padding: theme.spacing(1),
        display: 'flex',
        alignItems: 'center',
        [theme.breakpoints.down('sm')]: {
            width: '90%',
        },
        [theme.breakpoints.up('md')]: {
            width: '80%',
        },
        [theme.breakpoints.up('lg')]: {
            width: '60%',
        },
    },
    input: {
        marginLeft: 8,
        flex: 1,
    },
    iconButton: {
        padding: 5,
        color: '#5cb85c',
    },
    divider: {
        width: 1,
        height: 28,
        margin: 4,
    },
    container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    textField: {
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
    },
    dense: {
        marginTop: theme.spacing(2),
    },
    menu: {
        width: 200,
    },
    searchWrapper: {
        marginTop: 20,
        marginBottom: 30,
        paddingRight: 20,
        paddingLeft: 20,
        paddingTop: 20,
        paddingBottom: 20,
        boxShadow: '0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23)',
    },
    vAlignCenter: {
        display: 'flex',
        alignItems: 'center'
    },
    centerAlign: {
        marginBottom: 0
    }
});


@inject('articlesStore')
@observer
class SearchField extends React.Component {

    componentWillMount() {
        this.props.articlesStore.resetPredicate();
    }

    handleSearchText = (e) => {
        e.preventDefault();
        this.props.articlesStore.predicate[e.target.name] = e.target.value;
        this.props.articlesStore.predicate.isSearch = true;
        this.props.articlesStore.loadArticles();
    }

    handleSearchCheckbox = (e) => {
        e.preventDefault();
        this.props.articlesStore.predicate[e.target.name] = e.target.checked;
        this.props.articlesStore.predicate.isSearch = true;
        this.props.articlesStore.loadArticles();
    }

    handleSearch = (e) => {
        e.preventDefault();
        this.props.articlesStore.loadArticles();
    }


    render() {
        const { classes } = this.props;
        const { predicate } = this.props.articlesStore;

        return (
            <React.Fragment>
                <Grid container justify="center">
                    <Grid container xs={12} lg={8} justify="center" className={classes.searchWrapper} >
                        <Grid container item xs={12} lg={7} spacing={3}>
                            <Grid item xs={12} lg={6} >
                                <TextField
                                    label="From"
                                    name="from"
                                    variant="outlined"
                                    onChange={this.handleSearchText}
                                    fullWidth
                                />
                            </Grid>
                            <Grid item xs={12} lg={6} >
                                <TextField
                                    label="To"
                                    name="to"
                                    variant="outlined"
                                    onChange={this.handleSearchText}
                                    fullWidth
                                />
                            </Grid>
                        </Grid>
                        <Grid container item xs={12} lg={5} spacing={3}>
                            <Grid item xs={12} lg={8} className={classes.vAlignCenter}>
                                <FormControlLabel
                                    value="top"
                                    control={<Checkbox color="primary" name="withRequests"  onChange={this.handleSearchCheckbox} />}
                                    label="Requests"
                                    labelPlacement="start"
                                    className={classes.centerAlign}
                                />
                                <FormControlLabel
                                    value="top"
                                    control={<Checkbox color="primary" name="withDeliveries"  onChange={this.handleSearchCheckbox} />}
                                    label="Deliveries"
                                    labelPlacement="start"
                                    className={classes.centerAlign}
                                />
                            </Grid>
                            <Grid item xs={12} lg={4} className={classes.vAlignCenter}>
                                <Button fullWidth={true} size="large" variant="contained" color="primary" 
                                      className={classes.margin} onClick={this.handleSearch}>
                                    <SearchIcon />
                                </Button>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    };

}

export default withStyles(styles)(SearchField);
