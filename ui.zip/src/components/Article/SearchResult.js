import React from 'react';
import { inject, observer } from 'mobx-react';

import Grid from '@material-ui/core/Grid';

import ArticlePreview from './ArticlePreview';
import ListPagination from '../ListPagination';
import LoadingSpinner from '../LoadingSpinner';

import {
    withStyles,
} from '@material-ui/core';

const styles = theme => ({
    root: {
        flexGrow: 1,
    },
    card: {
        maxWidth: 250,
        maxHeight: 350,
        cardStyle: 5
    },
    cardStyle: {
        // margin: '5px',
        // padding: '5px',
        borderRadius: '3px'
    }

});

const ListDisplay = props => {
    const { classes } = props;
    return (
        props.articles.map(article => {
            return (
                <Grid key={article.id} item xs={12} sm={6} lg={3} >
                    <div className={classes.cardStyle}>
                        <ArticlePreview article={article} />
                    </div>
                </Grid>
            );
        })
    )
};

@inject('articlesStore')
@observer
class SearchResult extends React.Component {

    componentWillMount() {
        // this.props.articlesStore.resetPagination();
      }

    onPageClick = (offset, page) => {
        this.props.articlesStore.setPageOffset(offset);
        this.props.articlesStore.setPageNo(page - 1);
        this.props.articlesStore.loadArticles();
    }

    render() {

        const { classes } = this.props;
        const { articles, isLoading, pageOffset, pageLimit, totalElements } = this.props.articlesStore;

        if (isLoading) {
            return (
                <LoadingSpinner />
            );
        }

        if (articles.length === 0) {
            return (
                <React.Fragment>
                    <Grid container spacing={24}>
                        <Grid item xs={12} >
                            <div className="article-preview">
                                No articles are here... yet.
                            </div>
                        </Grid>
                    </Grid>
                </React.Fragment>
            );
        }


        return (
            <React.Fragment>
                <Grid container spacing={4} justify="center" >
                    <Grid container item xs={12} sm={12} lg={11} spacing={3}>
                        <ListDisplay articles={articles} classes={classes} />
                    </Grid>
                </Grid>
                <Grid container direction="row" justify="center" alignItems="center" spacing={24} className="m-t-2">
                   <ListPagination
                        pageOffset={pageOffset}
                        limit={pageLimit}
                        totalPages={totalElements}
                        onPageClick={this.onPageClick}
                        />
                </Grid>
            </React.Fragment>
        )
    };
}


export default withStyles(styles)(SearchResult);
