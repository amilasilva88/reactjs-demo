import React from 'react';
import Moment from 'react-moment';
import { inject, observer } from 'mobx-react';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';


import {
  Fab,
  Button,
  Typography,
  withStyles,
} from '@material-ui/core';

import {
  Grid,
  Segment,
  Icon,
  Divider
} from 'semantic-ui-react';

import {
  FacebookShareButton,
  TelegramShareButton,
  WhatsappShareButton,
  EmailShareButton,
  FacebookIcon,
  TelegramIcon,
  WhatsappIcon,
  EmailIcon,
} from 'react-share';

import { Map, Marker, Popup, TileLayer, Icon as PointerIcon } from 'react-leaflet';

import ArticleMeta from './ArticleMeta';
import ArticleOwner from './ArticleOwner';
import CommentContainer from '../Comment/CommentContainer';
import LoadingSpinner from '../LoadingSpinner';
import SearchField from './SearchField';
import OfferRequestDialog from '../Offers/OfferRequestDialog';
import OfferContainer from '../Offers/OfferContainer';
import dataFormatter from '../../utils/DataFormatter';


const styles = theme => ({
  grid: {
    flexGrow: 1,
  },
  shareIcons: {
    marginRight: '1.0rem',
    marginTop: '3px'
  }
});


@inject('articlesStore', 'userStore', 'offerRequestStore')
@withRouter
@observer
class Article extends React.Component {

  componentWillMount() {
    const id = this.props.match.params.id;
    this.props.articlesStore.loadArticle(id, { acceptCached: false });
    this.props.articlesStore.plusOne(id);
    this.props.offerRequestStore.findAcceptedOffer(id);
  }

  handleDeleteArticle = id => {
    this.props.articlesStore.deleteArticle(id)
      .then(() => this.props.history.replace('/'));
  };

  sanitize = val => {
    return (val === undefined || val == null || val.length <= 0) ? "" : val;
  }

  capitalize = s => {
    return (s) ?
      s.toLowerCase().replace(/\b./g, function (a) { return a.toUpperCase(); })
      : s;
  };

  numberFormat = n => {
    return (n) ? n.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,') : n;
  }

  handleOfferModalOpen = (articleId) => {
    this.props.offerRequestStore.currentArticleId(articleId);
    this.props.offerRequestStore.setOfferDialogOpen(true);
  };

  handleOfferComfirm = (offerId) => {
    this.props.offerRequestStore.confirmOffer(offerId);
  };


  render() {
    const slug = this.props.match.params.id;
    const { acceptedOfferDetails } = this.props.offerRequestStore;
    const { currentUser } = this.props.userStore;
    const article = this.props.articlesStore.currentArticle;

    const articleURL = this.props.articlesStore.getArticleURL(slug);
    const isLoading = this.props.articlesStore.isLoading;

    if (isLoading) return <LoadingSpinner />;

    const canModify = currentUser && currentUser.email === article.owner.email;

    const pickupLoc = article.pickupAddress;
    const dropoffLoc = article.dropoffAddress;

    const pickUpGeo = [pickupLoc.latitude, pickupLoc.longitude];
    const dropoffGeo = [dropoffLoc.latitude, dropoffLoc.longitude];
    const mapCenter = [article.midPoint.lat, article.midPoint.lon];
    const zoomLevel = article.mapZoomLevel;

    const pickupAddress = ((pickupLoc.unitNo) ? pickupLoc.unitNo + ', \n' : '')
      + ((pickupLoc.streetName) ? pickupLoc.streetName + ', \n' : '')
      + pickupLoc.cities.join() + ', \n'
      + pickupLoc.country;

    const dropOffAddress = ((dropoffLoc.unitNo) ? dropoffLoc.unitNo + ', \n' : '')
      + ((dropoffLoc.streetName) ? dropoffLoc.streetName + ', \n' : '')
      + dropoffLoc.cities.join() + ', \n'
      + dropoffLoc.country;

    const fbQuote = '${article.title} : ${articleURL}';

    const OffersTitle = canModify ? 'Offers' : 'Your Offers';

    const showBiddingOpts = (article.status === 'ASSIGNED')? false: true;;
    const hasAcceptedOffer = (currentUser && acceptedOfferDetails) ? true : false;

    return (
      <div className="article-page">
        <div className="banner">
          <div className="container">
            <h1>{article.title}</h1>
            <ArticleMeta
              article={article}
              canModify={canModify}
              onDelete={this.handleDeleteArticle}
            />
          </div>
        </div>

        <div className="container page">
          <div className="row article-content">
            <div className="col-xs-12">
              {showBiddingOpts && !canModify && !hasAcceptedOffer &&
                <Grid columns={1} padded justify="flex-end" alignitems="center">
                  <Grid.Column>
                    <Fab
                      variant="extended"
                      size="medium"
                      color="primary"
                      aria-label="Add"
                      onClick={() => this.handleOfferModalOpen(slug)}
                    >
                      Make Offer
                    </Fab>
                    <OfferRequestDialog />
                  </Grid.Column>
                </Grid>
              }
              {showBiddingOpts && !canModify && hasAcceptedOffer &&
                <Grid columns={1} padded justify="flex-end" alignitems="center">
                  <Grid.Column>
                    <Fab
                      variant="extended"
                      size="medium"
                      color="primary"
                      aria-label="Add"
                      onClick={() => this.handleOfferComfirm(acceptedOfferDetails.id)}
                    >
                      Confirm
                    </Fab>
                    <OfferRequestDialog />
                  </Grid.Column>
                </Grid>
              }

              <Grid stackable columns={2} padded>
                <Grid.Column >
                  <Segment>
                    <Typography component="p">
                      {this.capitalize(article.itemDesc)}
                    </Typography>
                    <Typography component="p">
                      <Icon name='money bill alternate outline' />{this.sanitize(article.currencyCode)} {this.numberFormat(article.price)}
                    </Typography>
                    <Typography component="p">
                      <Icon name='servicestack' />{this.capitalize(article.serviceMode)}
                    </Typography>
                    <Typography component="p">
                      <Icon name='pallet' />{this.capitalize(article.serviceType)}
                    </Typography>
                    <Typography component="p">
                      <Icon name='box' />{this.capitalize(article.deliveryItem)}
                    </Typography>
                    <Typography component="p">
                      <Icon name='shipping fast' />{this.capitalize(article.transportType)}
                    </Typography>
                    <Typography component="p">
                      <Icon name='balance scale' />{article.maxWeight} kg
                    </Typography>
                    <Typography component="p">
                      <i className="fas fa-tape"></i>{article.maxLength}cm x {article.maxWidth}cm x {article.maxHeigh}cm ({article.cbm} cbm)
                    </Typography>

                    <Divider inverted></Divider>
                    <Typography component="p">
                      <Icon name='clock outline' />
                      <Moment format="lll">{new Date(article.pickupDateTime).toISOString()}</Moment>
                    </Typography>
                    <Typography component="p">
                      <Icon name='circle notched' />Pickup Location(s)
                      </Typography>
                    <Typography component="p" className="m-l-1_5">
                      {pickupAddress}
                    </Typography>
                    <Typography component="p" className="m-l-1_5">
                      {article.pickupAddress.postcode}
                    </Typography>

                    <Divider inverted></Divider>
                    <Typography component="p">
                      <Icon name='clock' />
                      <Moment format="lll">{new Date(article.pickupDateTime).toISOString()}</Moment>
                    </Typography>
                    <Typography component="p">
                      <Icon name='point' />Drop-off Location(s)
                      </Typography>
                    <Typography component="p" className="m-l-1_5">
                      {dropOffAddress}
                    </Typography>
                    <Typography component="p" className="m-l-1_5">
                      {article.dropoffAddress.postcode}
                    </Typography>

                    <Divider inverted></Divider>

                    <Typography component="p">
                      <Icon name='bookmark outline' />Remarks: {article.remarks}
                    </Typography>

                    <Typography component="p">
                      <Icon name='delete calendar' />Listing Expire on:  <Moment format="lll">{new Date(article.expiryDate).toISOString()}</Moment>
                    </Typography>
                    <Divider inverted></Divider>
                    <Typography component="p">
                      <Icon name='send' />Sender: {this.capitalize(article.senderContact.name)}
                    </Typography>
                    <Typography component="p" className="m-l-1_5">
                      {article.senderContact.contactNo}
                    </Typography>
                    <Typography component="p" className="m-l-1_5">
                      {article.senderContact.email}
                    </Typography>
                    <Typography component="p" className="m-l-1_5">
                      {article.senderContact.note}
                    </Typography>
                    <Divider inverted></Divider>
                    {article.recipientContact.name &&
                      <React.Fragment>
                        <Typography component="p">
                          <Icon name='envelope open outline' />Recipient: {this.capitalize(article.recipientContact.name)}
                        </Typography>
                        <Typography component="p" className="m-l-1_5">
                          {article.recipientContact.contactNo}
                        </Typography>
                        <Typography component="p" className="m-l-1_5">
                          {article.recipientContact.email}
                        </Typography>
                        <Typography component="p" className="m-l-1_5">
                          {article.recipientContact.note}
                        </Typography>
                      </React.Fragment>
                    }
                    <Divider inverted></Divider>
                    <Typography component="p">
                      <Icon name="eye" />Views: {dataFormatter.nFormatter(this.props.articlesStore.viewCounter)}
                    </Typography>
                  </Segment>
                  <Segment>
                    <CommentContainer
                      entityType='article'
                      entityId={article.id}
                      currentUser={currentUser} />
                  </Segment>

                </Grid.Column>
                <Grid.Column>
                  <Segment>
                    <Map center={mapCenter} zoom={zoomLevel}>
                      <TileLayer
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"
                      />
                      <Marker position={pickUpGeo}>
                        <Popup>Pickup :{'\n' + pickupAddress}</Popup>
                      </Marker>
                      <Marker position={dropoffGeo}>
                        <Popup>Drop-off :{'\n' + dropOffAddress}</Popup>
                      </Marker>
                    </Map>

                  </Segment>
                  <Segment>
                    <div className="segment-title">
                      {OffersTitle}
                    </div>
                    <OfferContainer
                      articleId={slug}
                      owner={article.owner}
                      msgTitle={article.title}
                      msg={articleURL}
                      isOwner={canModify}
                      isOfferer={!canModify} />
                  </Segment>

                  <Segment>
                    <div className="segment-title">
                      Share This Listing
                    </div>
                    <Grid.Row className="shareButtons-left">
                      <FacebookShareButton
                        url={articleURL}
                        quote={fbQuote}
                        hashtag="#xeparcels"
                        className="share-icon">
                        <FacebookIcon size={32} round />
                      </FacebookShareButton>

                      <WhatsappShareButton
                        url={articleURL}
                        title={article.title}
                        separator=":: "
                        className="share-icon">
                        <WhatsappIcon size={32} round />
                      </WhatsappShareButton>

                      <TelegramShareButton
                        url={articleURL}
                        title={article.title}
                        className="share-icon">
                        <TelegramIcon size={32} round />
                      </TelegramShareButton>

                      <EmailShareButton
                        subject={article.title}
                        url={articleURL}
                        body={articleURL}
                        className="share-icon">
                        <EmailIcon size={32} round />
                      </EmailShareButton>

                    </Grid.Row>
                  </Segment>
                  <Segment>
                    <div className="segment-title">
                      About The Owner
                      </div>
                    <ArticleOwner owner={article.owner} msgTitle={article.title} msg={articleURL} />
                  </Segment>


                </Grid.Column>
              </Grid>
            </div>
          </div>
        </div>
      </div>
    );
  }
}


Article.propTypes = {
  classes: PropTypes.object.isRequired,
};


export default withStyles(styles)(Article)