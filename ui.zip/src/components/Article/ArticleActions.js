import { Link } from 'react-router-dom';
import React from 'react';

import Grid from '@material-ui/core/Grid';
import { Icon } from 'semantic-ui-react';

const ArticleActions = props => {
  const article = props.article;
  const handleDelete = () => props.onDelete(article.id);

  if (props.canModify) {
    return (
      <React.Fragment>
        <Grid container style={{ marginTop: 0.5 + 'em' }}  direction="row" justify="flex-start">
          <Grid item>
            <Link to={`/article/edit/${article.id}`} className="btn btn-outline-secondary btn-sm" style={{ marginRight: 0.5 + 'em' }}>
              <Icon bordered inverted color='black' name='edit' /> Edit Article
            </Link>

          </Grid>
          <Grid item >
            <button className="btn btn-outline-secondary btn-sm" onClick={handleDelete}>
              <Icon bordered inverted color='black' name='trash alternate' /> Delete Article
            </button>
          </Grid>
        </Grid>
      </React.Fragment>
    );
  }

  return null;
};

export default ArticleActions;
