import React from 'react';
import { inject, observer } from 'mobx-react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

import {
    Typography,
    withStyles
} from '@material-ui/core';

import {
    Form,
    Step,
    Grid,
    Segment,
    Icon,
    Image,
    Button
} from 'semantic-ui-react';


const styles = theme => ({
    grid: {
        flexGrow: 1,
    },
});

const steps = [
    {
        key: 'serviceMode',
        active: true,
        icon: 'truck',
        title: 'Select a Service',
        description: 'Choose your service option',
    },
    {
        key: 'details',
        active: false,
        icon: 'payment',
        title: 'Service Details',
        description: 'Enter service information',
    },
    { key: 'confirm', disabled: true, icon: 'info', title: 'Confirm' },
]



@inject('editorStore', 'userStore')
@observer
class ArticleEditorPg1 extends React.Component {

    constructor() {
        super();
    }



    render() {
        const { classes } = this.props;

        const { currentUser } = this.props.userStore;
        if (!currentUser || !currentUser.email) this.props.history.replace('/login')


        const {
            formTitle,
        } = this.props.editorStore;

        return (
            <div className="article-page p-1">
                <div className="container page">
                    <div className="row article-content">
                        <div className="col-xs-12">
                            <Grid stackable columns={1} padded>
                                <Grid.Column >
                                    <Segment>
                                        <div className="article-title">
                                            {formTitle}
                                        </div>
                                        {/* <Step.Group items={steps} /> */}
                                        <div className="m-x-1 m-y-1" >
                                            <Form>
                                                <Form.Group widths="equal" inline>
                                                    <Grid container columns={4} >
                                                        <Grid.Column tablet={4} computer={4}>
                                                        </Grid.Column>
                                                        <Grid.Column mobile={16} tablet={8} computer={4}>
                                                            <Link to={`/article/new-request`}>
                                                                <Button className="article-new-btn-select" >
                                                                    <Button.Content visible >
                                                                        <Image
                                                                            size='small'
                                                                            rounded
                                                                            src='./assets/img/boxes.png' />
                                                                    </Button.Content>
                                                                    <Typography component="p" variant="title" align="center">
                                                                        I've a Parcel to send
                                                                    </Typography>
                                                                </Button>
                                                            </Link>
                                                        </Grid.Column>
                                                        <Grid.Column mobile={16} tablet={8} computer={4}>
                                                            <Link to={`/article/new-delivery`}>
                                                                <Button className="article-new-btn-select">
                                                                    <Button.Content visible>
                                                                        <Image
                                                                            size='small'
                                                                            rounded
                                                                            src='./assets/img/delivery.png'
                                                                        />
                                                                    </Button.Content>
                                                                    <Typography component="p" variant="title" align="center">
                                                                        I can deliver your Parcel
                                                                    </Typography>
                                                                </Button>
                                                                
                                                            </Link>
                                                        </Grid.Column>
                                                        <Grid.Column tablet={4} computer={4}>
                                                        </Grid.Column>
                                                    </Grid>
                                                </Form.Group>
                                            </Form>
                                        </div>
                                    </Segment>
                                </Grid.Column>
                            </Grid>
                        </div>
                    </div>
                </div>

            </div >
        )
    };
}

ArticleEditorPg1.propTypes = {
    classes: PropTypes.object.isRequired,
}

export default withStyles(styles)(ArticleEditorPg1)
