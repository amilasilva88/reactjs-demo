import React from 'react';
import { inject, observer } from 'mobx-react';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import moment from 'moment';
import DatetimePicker from 'react-semantic-datetime';

import {
    Typography,
    withStyles,
} from '@material-ui/core';


import {
    Form,
    Divider,
    Grid,
    Segment,
    Icon,
    Step,
    Input,
} from 'semantic-ui-react';

import TermsAndConditionsDialog from './TermsAndConditionsDialog';
import LoadingSpinner from '../LoadingSpinner';
import CountryDropdown from '../util/CountryDropdown';
import CityDropdown from '../util/CityDropdown';
import CurrencyDropdown from '../util/CurrencyDropdown';
import ListErrors from '../ListErrors';

moment.locale('en');

const getModalStyle = () => {
    const top = 50;
    const left = 50;

    return {
        top: `${top}%`,
        left: `${left}%`,
        transform: `translate(-${top}%, -${left}%)`,
    };
}

const styles = theme => ({
    grid: {
        flexGrow: 1,
    },
    modalPaper: {
        position: 'absolute',
        width: theme.spacing(50),
        backgroundColor: theme.palette.background.paper,
        boxShadow: theme.shadows[5],
        padding: theme.spacing(40),
        outline: 'none',
    },
});

const steps = [
    {
        key: 'serviceMode',
        disabled: true,
        icon: 'truck',
        title: 'Select a Service',
        description: 'Choose your service option',
    },
    {
        key: 'details',
        active: true,
        icon: 'payment',
        title: 'Service Details',
        description: 'Enter service information',
    },
    { key: 'confirm', disabled: true, icon: 'info', title: 'Confirm' },
]



@inject('editorStore', 'userStore')
@withRouter
@observer
class ArticleDeliveryEditor extends React.Component {

    constructor() {
        super();
        this.state = {
            tagInput: '',
            pickupDateTime: moment(),
            pickupDateTimeOpen: false,
            validTillTime: moment(),
            validTillTimeOpen: false,
        };
    }

    componentWillMount() {
        this.props.editorStore.setArticleSlug(this.props.match.params.slug);
        this.props.editorStore.loadInitialData();
        this.props.editorStore.loadArticleData();
        this.props.editorStore.setFieldValue('serviceMode', 'delivery');
        this.props.editorStore.formTitle = 'New Delivery';
    }

    componentDidMount() {

    }

    changeTagInput = e => this.setState({ tagInput: e.target.value });

    handleChange = (e, { name, value }) => {
        this.props.editorStore.setFieldValue(name, value);

        // if (name == 'pickupAddress.country' || name == 'dropoffAddress.country') {
        //     this.props.editorStore.selectedcountries.push(value);
        // }
        this.setState({ [name]: value });
    }

    handlePickupCountryChange = (e, { name, value }) => {
        this.props.editorStore.setFieldValue(name, value);
        this.props.editorStore.pickupCountrySelected = value;
        this.props.editorStore.loadPickUpCities(value);

    }

    handleDropOffCountryChange = (e, { name, value }) => {
        this.props.editorStore.setFieldValue(name, value);
        this.props.editorStore.dropOffCountrySelected = value;
        this.props.editorStore.loadDropOffCities(value);
    }

    handleTagInputKeyDown = ev => {
        switch (ev.keyCode) {
            case 13: // Enter
            case 9: // Tab
            case 188: // ,
                if (ev.keyCode !== 9) ev.preventDefault();
                this.handleAddTag();
                break;
            default:
                break;
        }
    };

    handleAddTag = () => {
        if (this.state.tagInput) {
            this.props.editorStore.addTag(this.state.tagInput.trim());
            this.setState({ tagInput: '' });
        }
    };

    handleRemoveTag = tag => {
        if (this.props.editorStore.inProgress) return;
        this.props.editorStore.removeTag(tag);
    };

    submitForm = ev => {
        ev.preventDefault();
        const { editorStore } = this.props;
        const hasError = editorStore.validateDeliveryOrder();

        if (!hasError) {
            editorStore.submit()
                .then(content => {
                    editorStore.reset();
                    this.props.history.replace(`/article/${content.id}`)
                });
        }

    };

    handleTermsModalOpen = () => {
        this.props.editorStore.setTermsDialogOpen(true);
    };

    render() {

        const { classes } = this.props;
        const { currentUser } = this.props.userStore;
        if (!currentUser || !currentUser.email) this.props.history.replace('/login')

        const options = [
            { key: 'box', text: 'Box/es', value: 'box' },
            { key: 'document', text: 'Document/s', value: 'document' },
            { key: 'parcel', text: 'Parcel/s', value: 'parcel' },
            { key: 'food-in-bulk', text: 'Food in Bulk', value: 'food-in-bulk' },
            { key: 'fragile', text: 'Fragile Items', value: 'fragile' },
            { key: 'bag', text: 'Bag/s', value: 'bag' },
            { key: 'other', text: 'Other', value: 'other' },
        ];

        const bulkyOptions = [
            { key: 'van', text: 'Van', value: 'van' },
            { key: '10ft-lorry', text: '10ft. Lorry', value: '10ft-lorry' },
            { key: '14ft-lorry', text: '14ft. Lorry', value: '14ft-lorry' },
            { key: '24ft-lorry', text: '24ft. Lorry', value: '24ft-lorry' },
            { key: 'other1', text: 'Other', value: 'other' },
        ]

        const {
            inProgress,
            hasErrors,
            errors,
            article,
            formTitle,
            countries,
            pickupCities,
            dropOffCities,
            selectedcountries
        } = this.props.editorStore;

        const formError = hasErrors ? { 'error': 'Please correct the highlighted errors before post' } : {};

        return (
            <div className="article-page p-1">
                <div className="container page">
                    <div className="row article-content">
                        <div className="col-xs-12">
                            <Grid stackable columns={1} padded>
                                <Grid.Column >
                                    <Segment>
                                        <div className="article-title">
                                            {formTitle}
                                        </div>
                                        {/* <Step.Group items={steps} /> */}
                                        <LoadingSpinner show={inProgress} />
                                        <ListErrors errors={formError} />
                                        <div className="m-x-1 m-y-1" >
                                            <Form>
                                                <Form.Group inline>
                                                    <label>Item Type</label>
                                                    <Form.Radio
                                                        label='Small items'
                                                        name="serviceType"
                                                        value='small-items'
                                                        checked={article.serviceType === 'small-items'}
                                                        onChange={this.handleChange}
                                                        error={errors['serviceType']}
                                                    />
                                                    <Form.Radio
                                                        label='Bulky Items'
                                                        name="serviceType"
                                                        value='bulky-items'
                                                        checked={article.serviceType === 'bulky-items'}
                                                        onChange={this.handleChange}
                                                        error={errors['serviceType']}
                                                    />
                                                </Form.Group>

                                                <Form.Select fluid label='Delivery Mode' name="deliveryItem"
                                                    options={(article.serviceType === 'small-items') ? options : bulkyOptions}
                                                    placeholder='Delivery Mode'
                                                    widths="8"
                                                    value={article.deliveryItem}
                                                    onChange={this.handleChange}
                                                    error={errors['deliveryItem']} />

                                                <Form.Group inline>
                                                    <label>Max Weight</label>
                                                    <Input
                                                        label={{ basic: true, content: 'kg' }}
                                                        labelPosition='right'
                                                        placeholder='Enter weight...'
                                                        name="maxWeight"
                                                        onChange={this.handleChange}
                                                    />
                                                </Form.Group>

                                                <Form.Group inline grouped={true}>
                                                    <label>Max Dimensions</label>
                                                    <Input type='text'
                                                        label={{ basic: true, content: 'cm' }}
                                                        labelPosition='right'
                                                        placeholder='Length'
                                                        name="maxLength"
                                                        onChange={this.handleChange} />
                                                    <Input type='text'
                                                        label={{ basic: true, content: 'cm' }}
                                                        labelPosition='right'
                                                        placeholder='Width'
                                                        name="maxWidth"
                                                        onChange={this.handleChange} />
                                                    <Input type='text'
                                                        label={{ basic: true, content: 'cm' }}
                                                        labelPosition='right'
                                                        placeholder='Height'
                                                        name="maxHeight"
                                                        onChange={this.handleChange} />
                                                </Form.Group>

                                                <Form.Group grouped={true}>
                                                    <label>Description</label>
                                                    <Typography variant="caption" gutterBottom>
                                                        Describe about your cargo item/s you can deliver. eg: Max no of units, (2 parcels and 1 boxes), allowed item content, etc..
                                                    </Typography>
                                                    <Form.TextArea name="itemDesc" placeholder='Tell more about your service' value={article.itemDesc}
                                                        onChange={this.handleChange} error={errors['itemDesc']} />
                                                </Form.Group>

                                                {/*
                                                <Form.Group inline>
                                                    <label>Transport Type</label>
                                                    <Form.Radio
                                                        label='Domestic/Local'
                                                        name="transportType"
                                                        value='local'
                                                        checked={article.transportType === 'local'}
                                                        onChange={this.handleChange}
                                                        error={errors['transportType']}
                                                    />
                                                    <Form.Radio
                                                        label='International'
                                                        name="transportType"
                                                        value='international'
                                                        checked={article.transportType === 'international'}
                                                        onChange={this.handleChange}
                                                        error={errors['transportType']}
                                                    />
                                                </Form.Group>
                                                */}

                                                <Form.Group inline>
                                                    <label>Pick up service details</label>
                                                </Form.Group>
                                                <Segment>
                                                    <Form.Group>
                                                        <CountryDropdown fluid label='Country' name="pickupAddress.country" placeholder='Country' width={4} value={article.pickupAddress.country}
                                                            countries={countries} onChange={this.handlePickupCountryChange} error={errors['pickupAddress'] || errors['pickupAddress.country']} />
                                                        <CityDropdown fluid multiple label='Cities' name="pickupAddress.cities" placeholder='Cities' width={6} value={article.pickupAddress.cities}
                                                            cities={pickupCities} onChange={this.handleChange} error={errors['pickupAddress'] || errors['pickupAddress.cities']} />
                                                    </Form.Group>
                                                    {/*
                                                    <Divider horizontal></Divider>
                                                    <Form.Group>
                                                        <Form.Input
                                                            label='Pickup On/Before Date and Time'
                                                            name="pickupAddress.pickupDateTime"
                                                            action={{ color: "black", icon: "calendar", onClick: () => this.setState({ pickupDateTimeOpen: true }) }}
                                                            actionPosition="left"
                                                            value={moment(this.state.pickupDateTime).format('LLL')}
                                                            onClick={() => this.setState({ pickupDateTimeOpen: true })}
                                                            disabled={this.state.pickupDateTimeOpen}
                                                            fluid
                                                            width={8}
                                                            error={errors['pickupDateTime']}
                                                        />

                                                        {this.state.pickupDateTimeOpen && <DatetimePicker
                                                            onChange={(value) => {
                                                                this.setState({ pickupDateTime: value.valueOf(), pickupDateTimeOpen: false })
                                                                this.props.editorStore.setFieldValue('pickupDateTime', value.valueOf());
                                                            }}
                                                            moment={this.pickupDateTime}
                                                            time={true}
                                                        />}
                                                    </Form.Group>
                                                        */}
                                                </Segment>

                                                <Form.Group inline>
                                                    <label>Drop off service details</label>
                                                </Form.Group>
                                                <Segment>
                                                    <Form.Group>
                                                        <CountryDropdown fluid label='Country' name="dropoffAddress.country" placeholder='Country' width={4} value={article.dropoffAddress.country}
                                                            countries={countries} onChange={this.handleDropOffCountryChange} error={errors['dropoffAddress'] || errors['dropoffAddress.country']} />
                                                        <CityDropdown fluid multiple label='Cities' name="dropoffAddress.cities" placeholder='Cities' width={6} value={article.dropoffAddress.cities}
                                                            cities={dropOffCities} onChange={this.handleChange} error={errors['dropoffAddress'] || errors['dropoffAddress.cities']} />
                                                    </Form.Group>
                                                    {/*
                                                    <Divider horizontal></Divider>
                                                    <Form.Group>
                                                        <Form.Input
                                                            label='Drop off Date and Time'
                                                            action={{ color: "black", icon: "calendar", onClick: () => this.setState({ dropoffDateTimeOpen: true }) }}
                                                            actionPosition="left"
                                                            value={moment(this.state.dropoffDateTime).format('LLL')}
                                                            onClick={() => this.setState({ dropoffDateTimeOpen: true })}
                                                            disabled={this.state.dropoffDateTimeOpen}
                                                            fluid
                                                            width={8}
                                                            error={errors['dropoffDateTime']}
                                                        />

                                                        {this.state.dropoffDateTimeOpen && <DatetimePicker
                                                            onChange={(value) => {
                                                                this.setState({ dropoffDateTime: value.valueOf(), dropoffDateTimeOpen: false })
                                                                this.props.editorStore.setFieldValue('dropoffDateTime', value.valueOf());
                                                            }}
                                                            moment={this.dropoffDateTime}
                                                            time={true}
                                                        />}

                                                    </Form.Group>
                                                        */}
                                                </Segment>
                                                <Form.Group>
                                                    <Form.Input
                                                        label='Valid Till'
                                                        action={{ color: "black", icon: "calendar", onClick: () => this.setState({ validTillTimeOpen: true }) }}
                                                        actionPosition="left"
                                                        value={moment(this.state.validTillTime).format('LLL')}
                                                        onClick={() => this.setState({ validTillTimeOpen: true })}
                                                        disabled={this.state.validTillTimeOpen}
                                                        fluid
                                                        width={8}
                                                        error={errors['validTillTime']}
                                                    />
                                                    
                                                    {this.state.validTillTimeOpen && <DatetimePicker
                                                        onChange={(value) => {
                                                            this.setState({ validTillTime: value.valueOf(), validTillTimeOpen: false })
                                                            this.props.editorStore.setFieldValue('validTillTime', value.valueOf());
                                                        }}
                                                        moment={this.validTillTime}
                                                        time={true}
                                                    />}

                                                </Form.Group>

                                                <Form.Group>

                                                    <CurrencyDropdown
                                                        label="Currency"
                                                        name="currencyCode"
                                                        placeholder='Currency'
                                                        selectedcountries={selectedcountries}
                                                        value={article.currencyCode}
                                                        onChange={this.handleChange}
                                                        error={errors['currencyCode']}
                                                    />

                                                    <Form.Input
                                                        label="Unit price per kg or dimension unit"
                                                        name="price"
                                                        type='text'
                                                        placeholder='Amount'
                                                        value={article.price}
                                                        onChange={this.handleChange}
                                                        error={errors['price']}>
                                                    </Form.Input>
                                                </Form.Group>

                                                <Form.TextArea label='Remarks' name="remarks" placeholder='Any other extra information...' value={article.remarks} onChange={this.handleChange} />

                                                <Segment>
                                                    <Grid stackable columns={2} padded>
                                                        <Grid.Column>
                                                            <label className="article-content">Contact Info</label>
                                                            <Form.Input fluid name="senderContact.name" placeholder="Name/Compnay Name" width={12} value={article.senderContact.name}
                                                                onChange={this.handleChange} error={errors['senderContact'] || errors['senderContact.name']} />
                                                            <Form.Input fluid name="senderContact.contactNo" placeholder="Contact No." width={12}
                                                                value={article.senderContact.contactNo} onChange={this.handleChange} error={errors['senderContact'] || errors['senderContact.contactNo']} />
                                                            <Form.Input fluid name="senderContact.email" placeholder="Email" width={12} value={article.senderContact.email} onChange={this.handleChange} />
                                                            <Form.Input fluid name="senderContact.note" placeholder="Notes" width={12} value={article.senderContact.note} onChange={this.handleChange} />
                                                        </Grid.Column>
                                                    </Grid>
                                                    <Form.Checkbox name="showPersonalInfo" label='Show my contacts in public post' value='true' onChange={this.handleChange} error={errors['showPersonalInfo']} />
                                                </Segment>

                                                <Form.Group inline>
                                                    <Form.Checkbox name="termsCheck"
                                                        label="I have read and agree to the"
                                                        value='true'
                                                        onChange={this.handleChange} error={errors['termsCheck']} />
                                                    <a onClick={this.handleTermsModalOpen} className="terms-and-condition">
                                                        Terms and Conditions
                                                    </a>
                                                    <TermsAndConditionsDialog />
                                                </Form.Group>

                                                <ListErrors errors={formError} />
                                                <button
                                                    className="btn btn-lg btn-primary pull-xs-right"
                                                    type="submit"
                                                    disabled={inProgress}
                                                    onClick={this.submitForm} >
                                                    Publish
                                                </button>
                                                <br />
                                                <br />
                                            </Form>
                                        </div>
                                    </Segment>
                                </Grid.Column>
                            </Grid>
                        </div>
                    </div>
                </div>

            </div>
        )
    };
}

ArticleDeliveryEditor.propTypes = {
    classes: PropTypes.object.isRequired,
}

export default withStyles(styles)(ArticleDeliveryEditor)
