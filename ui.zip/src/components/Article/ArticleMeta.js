import React from 'react';
import { observer } from 'mobx-react';
import { Link } from 'react-router-dom';
import Avatar from 'react-avatar';

import ArticleActions from './ArticleActions';


const ArticleMeta = observer(props => {
  const article = props.article;
  return (
    <React.Fragment>
      <div className="article-meta">
        <Link to={`/@${article.owner.userId}`}>
          <Avatar name={article.owner.displayName}
            size={45}
            round={true}
            textSizeRatio={2}
            src={article.owner.avatarPath} />
        </Link>

        <div className="info">
          <Link to={`/@${article.owner.userId}`} className="author">
            {article.owner.displayName}
          </Link>
          <span className="date">
            {new Date(article.modifiedTime).toDateString()}
          </span>
        </div>

        <ArticleActions canModify={props.canModify} article={article} onDelete={props.onDelete} />
      </div>
    </React.Fragment>
  );
});

export default ArticleMeta;
