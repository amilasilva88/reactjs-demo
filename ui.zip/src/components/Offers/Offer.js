import React from 'react';
import Moment from 'react-moment';
import { Link } from 'react-router-dom';
import Avatar from 'react-avatar';

import AcceptButton from './AcceptButton';

import { Label } from 'semantic-ui-react'


const Offer = props => {
  const {id, offer, currentUser, onAccept} = props;
  const accepted = (offer.status === 'ACCEPTED') ? true : false;

  return (
    <div className="card comment-form">
      <div className="offer-card-block">
        <span className="card-text">{offer.comment}</span>
        <Label.Group tag className="card-text offer-value">
            <Label className={accepted? 'offer-label-accepted': ''}>{accepted? offer.status + ' - ': ''} ${offer.offerValue}</Label>
        </Label.Group>
      </div>
      <div className="card-footer offer-footer">
          <div className="article-meta">
            <Link to={`/@${offer.owner.userId}`}>
              <Avatar name={offer.owner.displayName}
                size={25}
                round={true}
                textSizeRatio={2}
                src={offer.owner.avatarPath} />
            </Link>

            <div className="info">
              <Link to={`/@${offer.owner.userId}`} className="author">
                {offer.owner.displayName}
              </Link>
              <span className="date">
                <Moment fromNow>{new Date(offer.modifiedTime).toISOString()}</Moment>
              </span>
            </div>

            {!accepted &&
              <AcceptButton
                offerId={offer.id}
                show={true}
                onAccept={props.onAccept}
              />
            }  
          </div>
      </div>
    </div>
  );
};

export default Offer;
