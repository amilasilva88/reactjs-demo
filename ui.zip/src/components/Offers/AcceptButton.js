import React from 'react';

const AcceptButton = props => {
  
  const {offerId} = props;
  const handleAccept = () => props.onAccept(offerId);

  if (props.show) {
    return (
      <button
        className="btn btn-sm btn-primary"
        type="submit"
        onClick={handleAccept}>
        <i className="fas fa-gavel"/> Accept
      </button>
    );
  }
  return null;
};

export default AcceptButton;
