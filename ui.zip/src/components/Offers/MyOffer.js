import React from 'react';

import { Label } from 'semantic-ui-react'


const MyOffer = props => {
  const {offer} = props;

  const accepted = (offer.status === 'ACCEPTED') ? true : false;

  return (
    <div className="card comment-form">
      <div className="offer-card-block">
        <span className="card-text">{offer.comment}</span>
        <Label.Group tag className="card-text offer-value">
            <Label className={accepted? 'offer-label-accepted': ''}>{accepted? offer.status + ' - ': ''} ${offer.offerValue}</Label>
        </Label.Group>
      </div>
    </div>
  );
};

export default MyOffer;
