import React from 'react';
import { observer } from 'mobx-react';

import Offer from './Offer';
import MyOffer from './MyOffer';

const OfferList = observer(props => {

  return (
    <div>
      {props.showOwnerView &&
        props.offers.map(offer => {
          return (
            <Offer
              id={offer.id}
              key={offer.id}
              offer={offer}
              onAccept={props.onAccept}
            />
          );
        })
      }
      {props.showOffererView &&
        props.offers.map(offer => {
          return (
            <MyOffer
              id={offer.id}
              key={offer.id}
              offer={offer}
            />
          );
        })
      }
    </div>
  );
});

export default OfferList;
