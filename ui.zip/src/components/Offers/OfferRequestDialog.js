import React from 'react';
import { Link, withRouter } from 'react-router-dom';
import { inject, observer } from 'mobx-react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';

import {
    Button,
    Dialog,
    DialogTitle,
    DialogContentText,
    DialogContent,
    DialogActions,
    TextField,
} from '@material-ui/core';



const styles = theme => ({
    root: {
        padding: theme.spacing(1),
        display: 'flex',
        alignItems: 'center',
        [theme.breakpoints.down('sm')]: {
            width: '90%',
        },
        [theme.breakpoints.up('md')]: {
            width: '80%',
        },
        [theme.breakpoints.up('lg')]: {
            width: '80%',
        },
    },

});

@inject('offerRequestStore', 'userStore')
@withRouter
@observer
class OfferRequestDialog extends React.Component {

    state = {
        scroll: 'paper',
    };

    componentWillMount() {

    }

    handleClickOpen = scroll => () => {
        this.setState({ open: true, scroll });
    };

    handleClose = () => {
        this.props.offerRequestStore.reset()
        this.props.offerRequestStore.setOfferDialogOpen(false);
    };

    handleSubmit = () => {

        if (this.props.offerRequestStore.validateOffer()) {
            return;
        }
        this.props.offerRequestStore.submitOffer();
        this.props.offerRequestStore.setOfferDialogOpen(false);
    };


    handleChange = (e) => {
        this.props.offerRequestStore.setFieldValue(e.target.id, e.target.value);
    }


    render() {
        const { offerDialogOpen, errors } = this.props.offerRequestStore;
        const { currentUser } = this.props.userStore;
        if (offerDialogOpen && (!currentUser || !currentUser.email)) this.props.history.push('/login')

        return (
            <Dialog
                open={offerDialogOpen}
                onClose={this.handleClose}
                scroll={this.state.scroll}
                aria-labelledby="scroll-dialog-title"
            >
                <DialogTitle id="scroll-dialog-title">Offer Request</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Make an offer to this request
                    </DialogContentText>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="offerValue"
                        label="Offer value"
                        type="number"
                        required
                        onChange={this.handleChange}
                        error={errors && errors['offerValue']}
                    />
                    <TextField
                        margin="dense"
                        id="comment"
                        label="Comment"
                        type="text"
                        onChange={this.handleChange}
                        fullWidth
                        required
                        error={errors && errors['comment']}
                    />
                </DialogContent>

                <DialogActions>
                    <Button onClick={this.handleSubmit} color="primary">
                        Save
                    </Button>
                    <Button onClick={this.handleClose} color="secondary">
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        );
    };

}

export default withStyles(styles)(OfferRequestDialog);