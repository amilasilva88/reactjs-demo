import React from 'react';
import { Link, withRouter } from 'react-router-dom';
import { inject, observer } from 'mobx-react';

import OffersList from './OfferList';
import RedError from '../RedError';

import {
  Divider,
} from 'semantic-ui-react';


@inject('offerRequestStore', 'userStore')
@withRouter
@observer
class OfferContainer extends React.Component {

  componentWillMount() {
    this.props.offerRequestStore.setArticleSlug(this.props.articleId);

    if (this.props.isOwner) {
      this.props.offerRequestStore.loadOfferRequestByArticle(this.props.articleId);
    }

    if (this.props.isOfferer) {
      this.props.offerRequestStore.loadUserOfferRequestsForArticle(this.props.articleId);
    }

  }

  componentDidMount() {

  }

  onAccept = (offerId) => {
    this.props.offerRequestStore.acceptOffer(offerId);
  };

  render() {
    const { articleId, isOwner, isOfferer } = this.props;
    const { articleOffers } = this.props.offerRequestStore;
    const { currentUser } = this.props.userStore;

    if (!articleOffers) return <RedError message="unable to load the Offers" />;

    if (!currentUser) {
      return (
        <div className="col-xs-12">
          <p>
            <Link to="/login">Sign in</Link>
            &nbsp;or&nbsp;
        <Link to="/register">sign up</Link>
            &nbsp;to make an offer for this article.
      </p>
        </div>
      );
    }

    return (
      <div className="col-xs-12">
        <OffersList
          articleId={articleId}
          offers={articleOffers}
          onAccept={this.onAccept}
          showOwnerView={isOwner}
          showOffererView={isOfferer}
        />
      </div>
    );

  }
}

export default OfferContainer;
