import PropTypes from 'prop-types';

import createShareButton from 'react-share/lib/utils/createShareButton';


function objectToGetParams(object) {
    return Object.keys(object)
        .filter(key => !!object[key])
        .map(key => `${key}=${encodeURIComponent(object[key])}`)
        .join('&');
}

function emailLink(url, { to, subject, body }) {
    return 'mailto:' + to + '?' + objectToGetParams({ subject, body: body || url });
}

const EmailMsgButton = createShareButton('email', emailLink, props => ({
    to: props.to,
    subject: props.subject,
    body: props.body,
}), {
        to: PropTypes.string,
        subject: PropTypes.string,
        body: PropTypes.string,
    }, {
        openWindow: false,
        onClick: (link) => { window.location.href = link; },
    });

export default EmailMsgButton;