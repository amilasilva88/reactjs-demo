import PropTypes from 'prop-types';
import assert from 'assert';

import createShareButton from 'react-share/lib/utils/createShareButton';

function whatsappLink(url, { phone, title, separator }) {
  // assert(url, 'whatsapp.url');
  return 'https://api.whatsapp.com/send?phone=' + phone + '&' + objectToGetParams({
    text: title ? title + separator + url : url,
  });
}

function objectToGetParams(object) {
  return Object.keys(object)
    .filter(key => !!object[key])
    .map(key => `${key}=${encodeURIComponent(object[key])}`)
    .join('&');
}

const WhatsappMsgButton = createShareButton('whatsapp', whatsappLink, props => ({
  phone: props.phone,
  title: props.title,
  separator: props.separator,
}), {
    phone: PropTypes.string,
    title: PropTypes.string,
    separator: PropTypes.string,
  }, {
    separator: ' ',
    windowWidth: 550,
    windowHeight: 400,
  });

export default WhatsappMsgButton;