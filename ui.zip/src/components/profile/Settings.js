import React from 'react';
import { inject, observer } from 'mobx-react';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import CountryDropdown from '../util/CountryDropdown';

import ImageUploader from 'react-images-upload';

import { withStyles } from '@material-ui/core/styles';

import {
  Form,
  Grid,
  Segment,
} from 'semantic-ui-react';

import ListErrors from '../ListErrors';

const styles = theme => ({
  root: {
    flexGrow: 1,
  },
  grid: {
    flexGrow: 1,
  }
});

@inject('userStore')
@observer
class UserProfileForm extends React.Component {

  constructor() {
    super();

    this.state = { pictures: [] };
    this.onDrop = this.onDrop.bind(this);

    this.handleChange = (e, { name, value }) => {
      this.props.userStore.setFieldValue(name, value);
    }

    this.submitForm = ev => {
      ev.preventDefault();
      const user = this.props.userStore.userProfile;
      if (!user.password) {
        delete user.password;
      }
      this.props.onSubmitForm(user);
    };
  }

  onDrop(pictureFiles, pictureDataURLs) {
    // raw image data
    this.props.userStore.setFieldValue("thumbnail", pictureDataURLs[0]);
  }


  componentWillMount() {
    this.props.userStore.loadInitialData();

    if (this.props.userStore.currentUser) {
      // Object.assign(this.state, {
      //   image: this.props.userStore.currentUser.image || '',
      //   username: this.props.userStore.currentUser.username,
      //   bio: this.props.userStore.currentUser.bio || '',
      //   email: this.props.userStore.currentUser.email
      // });
    }
  }

  render() {
    const { currentUser } = this.props;
    const { countries } = this.props.userStore;

    return (
      <Segment>
        <div className="article-title">
          Profile
        </div>
        <Segment>
          <div className="m-x-1 m-y-1">
            <Form>
              <Form.Input fluid label='Displayname'
                name="displayName"
                placeholder='Display name'
                value={currentUser.displayName}
                onChange={this.handleChange} />

              <Form.Input fluid label='E-mail'
                name="email"
                placeholder='E-mail'
                value={currentUser.email}
                onChange={this.handleChange} />

              <Form.Input fluid label='Phone number'
                name="phoneNumber"
                placeholder='Phone number'
                value={currentUser.phoneNumber}
                onChange={this.handleChange} />

              <CountryDropdown fluid label='Country' name="country"
                placeholder='Country' value={currentUser.country}
                countries={countries} onChange={this.handleChange}
                 />

              <Form.TextArea label='Bio'
                name="bio"
                placeholder='Tell us more about yourself'
                value={currentUser.bio}
                onChange={this.handleChange} />

              <Form.Field>
                <label>Profile Picture</label>
                <ImageUploader
                  withIcon={true}
                  buttonText='Choose images'
                  onChange={this.onDrop}
                  imgExtension={['.jpg', '.gif', '.png', '.gif']}
                  maxFileSize={5242880}
                  withPreview={true}
                  singleImage={true}
                  label="Max file size: 5mb"
                />
              </Form.Field>

              <button className="btn btn-lg btn-primary pull-xs-right"
                type="submit" onClick={this.submitForm} >
                Save
              </button>
            </Form>
            <br />
            <br />
          </div>
        </Segment >
      </Segment >

    );
  }
}



@inject('userStore', 'authStore')
@withRouter
@observer
class Settings extends React.Component {

  updateProfile(user) {

    this.props.userStore.updateProfile(user)
      .then(content => {
        //editorStore.reset();
        this.props.history.replace(`/@${user.email}`)
      });
  }

  render() {

    return (
      <Grid stackable columns={1}>
        <Grid.Column >
          <ListErrors errors={this.props.userStore.updatingUserErrors} />

          <UserProfileForm
            currentUser={this.props.userStore.userProfile}
            onSubmitForm={user => this.updateProfile(user)} />

        </Grid.Column>
      </Grid>
    );
  }
}

Settings.propTypes = {
  classes: PropTypes.object.isRequired,
}

export default withStyles(styles)(Settings);
