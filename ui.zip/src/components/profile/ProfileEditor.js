
import React from 'react';
import { NavLink, Link, withRouter } from 'react-router-dom';
import { inject, observer } from 'mobx-react';

import LoadingSpinner from '../LoadingSpinner';
import RedError from '../RedError';

import Settings from './Settings';
import UserProfilePreview from './UserProfilePreview';

import {
  Grid
} from 'semantic-ui-react';


@inject('profileStore', 'userStore')
@withRouter
@observer
export default class ProfileEditor extends React.Component {

  componentWillMount() {
    this.props.profileStore.loadProfile(this.props.match.params.userId);
  }

  componentDidUpdate(previousProps) {
    if (this.props.location !== previousProps.location) {
      this.props.profileStore.loadProfile(this.props.match.params.userId);
    }
  }

  render() {
    const { profileStore, userStore } = this.props;
    const { profile, isLoadingProfile } = profileStore;
    const { currentUser } = userStore;

    if (isLoadingProfile && !profile) return <LoadingSpinner />;
    if (!profile) return <RedError message="Can't load profile" />;

    const isLoggedInUser = currentUser && profile.username === currentUser.username;

    return (
      <div className="article-page p-1">

        <div className="container page">
          <div className="row article-content">
            <div className="col-xs-12 col-md-4">
              <Grid stackable columns={1} padded>
                <Grid.Column >
                  <UserProfilePreview profile={profile} isLoggedInUser={isLoggedInUser} />
                </Grid.Column>
              </Grid>
            </div>
            <div className="col-xs-12 col-md-8">
              <Grid stackable columns={1} padded>
                <Grid.Column >
                  <Settings />
                </Grid.Column>
              </Grid>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export { ProfileEditor };
