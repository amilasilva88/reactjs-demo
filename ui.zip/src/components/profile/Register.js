import React from 'react';
import { inject, observer } from 'mobx-react';
import { Link } from 'react-router-dom';
import {
  Form,
  Divider,
  Grid,
  Segment,
  Label,
  Icon
} from 'semantic-ui-react';

import ListErrors from '../ListErrors';

@inject('authStore')
@observer
export default class Register extends React.Component {

  constructor() {
    super();
  }

  componentWillUnmount() {
    this.props.authStore.reset();
  }

  handleChange = (e) => {
    this.props.authStore.setFieldValue(e.target.name, e.target.value);
  }

  handleSubmitForm = (e) => {
    e.preventDefault();
    let hasErrors = this.props.authStore.validate();

    if (!hasErrors)
      this.props.authStore.register()
        .then(() => this.props.history.replace('/'))
        .catch((err) => {
          hasErrors = true;
        });
  };

  render() {
    const { values, errors, inProgress } = this.props.authStore;

    return (
      <div className="auth-page">
        <div className="container page">
          <div className="row">

            <div className="col-md-6 offset-md-3 col-xs-12">
              <h1 className="text-xs-center">Sign Up</h1>
              <p className="text-xs-center">
                <Link to="login">
                  Have an account?
                </Link>
              </p>

              <ListErrors errors={errors} />

              <form>
                <fieldset>
                  <fieldset className="form-group">
                    <input
                      className="form-control form-control-lg"
                      type="text"
                      name="displayName"
                      placeholder="Display Name"
                      value={values.displayName}
                      onChange={this.handleChange}
                      error={errors['displayName']}
                    />
                  </fieldset>

                  <fieldset className="form-group">
                    <input
                      className="form-control form-control-lg"
                      type="email"
                      name="email"
                      placeholder="Email"
                      value={values.email}
                      onChange={this.handleChange}
                      error={errors['email']}
                    />
                  </fieldset>

                  <fieldset className="form-group">
                    <input
                      className="form-control form-control-lg"
                      type="password"
                      name="password"
                      placeholder="Password"
                      value={values.password}
                      onChange={this.handleChange}
                      error={errors['password']}
                    />
                  </fieldset>

                  <button
                    className="btn btn-lg btn-primary pull-xs-right"
                    type="submit"
                    disabled={inProgress}
                    onClick={this.handleSubmitForm}
                  >
                    Sign in
                  </button>

                </fieldset>
              </form>
            </div>

          </div>
        </div>
      </div>
    );
  }
}
