import React from 'react';
import Moment from 'react-moment';
import PropTypes from 'prop-types';
import { withRouter, Link } from 'react-router-dom';
import { inject, observer } from 'mobx-react';
import Avatar from 'react-avatar';

import {
    withStyles,
} from '@material-ui/core';

import { Segment, Icon } from 'semantic-ui-react';

import CommentContainer from '../Comment/CommentContainer';
import Feedback from '../util/Feedback';
import FollowButton from '../util/FollowButton';

import RedError from '../RedError';

const styles = theme => ({
    root: {
        flexGrow: 1,
    }

});

const LoggedInUserView = props => {

    if (props.isLoggedInUser) {
        return (
            <button
                className="btn btn-lg btn-outline-primary btn-follow"
                type="submit"
                onClick={props.onLogout}>
                <i className="fas fa-power-off" /> Logout
            </button >
        );
    }
    return null;
};


@inject('authStore', 'userStore', 'commentsStore')
@withRouter
@observer
class UserProfilePreview extends React.Component {


    handleLogout = ev => {
        ev.preventDefault();
        this.props.authStore.logout();
    };

    render() {
        const { profile, isLoggedInUser } = this.props;
        const { currentUser, loadingProfilePrev } = this.props.userStore;

        if (!currentUser || !currentUser.email) this.props.history.replace('/');

        // const markup = { __html: marked(article.itemDesc, { sanitize: true }) };

        return (
            <div>
                <Segment>
                    <div>
                        <div className="article-owner">
                            <Avatar name={profile.displayName}
                                round={true}
                                size={75}
                                textSizeRatio={2}
                                src={profile.avatarPath} />

                            <div className="ownerInfo">
                                <span className="author">
                                    {profile.displayName}
                                </span>
                                <span className="date">
                                    Joined <Moment format='MMM, YYYY'>{new Date(profile.since).toISOString()}</Moment>
                                </span>
                                <div className="date">
                                    {profile.country}
                                    {(isLoggedInUser) ?
                                        <Link to={`/profile/edit/@${profile.email}`} className="btn btn-sm" style={{ marginTop: 0.5 + 'em' }}>
                                            <Icon bordered color='black' name='edit' />
                                        </Link>
                                        : ""
                                    }
                                </div>
                            </div>
                        </div>
                        <div className="m-t-1">
                            <LoggedInUserView isLoggedInUser={isLoggedInUser} onLogout={this.handleLogout} />
                            <FollowButton isLoggedInUser={isLoggedInUser} profile={profile}
                                loading={loadingProfilePrev} />
                        </div>
                    </div>
                </Segment>
                <Segment>
                    <div>
                        <div className="segment-title">
                            Feedback
                        </div>
                        <Feedback entityType='user' enityId={profile.userId} />
                    </div>
                </Segment>
                <Segment>
                    <CommentContainer entityType='user' entityId={profile.userId} currentUser={currentUser}/>
                </Segment>
            </div >
        );
    }
}


UserProfilePreview.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(UserProfilePreview);