import React from 'react';
import { inject, observer } from 'mobx-react';
import { withRouter, Link } from 'react-router-dom'
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import {
    Map,
    CircleMarker,
    Marker,
    Popup,
    Tooltip,
    TileLayer,
    WMSTileLayer,
    Icon as PointerIcon
} from 'react-leaflet';
import MarkerClusterGroup from 'react-leaflet-markercluster';
import 'react-leaflet-markercluster/dist/styles.min.css';

const center = [51.0, 19.0];
const mapStyle = { height: "440px", width: "100%" };

@inject('landingPageStore')
@observer
class HotspotMapView extends React.Component {


    render() {
        const { countrySummaryValues } = this.props.landingPageStore;


        console.log(countrySummaryValues);
        console.log(":::::::: Country SUmmary:" + JSON.stringify(countrySummaryValues))

        let data = {
            city: [
                { "name": "Tokyo", "coordinates": [139.6917, 35.6895], "population": 37843000 },
                { "name": "Jakarta", "coordinates": [106.8650, -6.1751], "population": 30539000 },
                { "name": "Delhi", "coordinates": [77.1025, 28.7041], "population": 24998000 },
                { "name": "Seoul", "coordinates": [126.9780, 37.5665], "population": 23480000 },
                { "name": "Shanghai", "coordinates": [121.4737, 31.2304], "population": 23416000 },
                { "name": "Karachi", "coordinates": [67.0099, 24.8615], "population": 22123000 },
                { "name": "Beijing", "coordinates": [116.4074, 39.9042], "population": 21009000 },
                { "name": "Mumbai", "coordinates": [72.8777, 19.0760], "population": 17712000 },
                { "name": "Osaka", "coordinates": [135.5022, 34.6937], "population": 17444000 },
                { "name": "Moscow", "coordinates": [37.6173, 55.7558], "population": 16170000 },
                { "name": "Dhaka", "coordinates": [90.4125, 23.8103], "population": 15669000 },
                { "name": "Bangkok", "coordinates": [100.5018, 13.7563], "population": 14998000 },
                { "name": "Kolkata", "coordinates": [88.3639, 22.5726], "population": 14667000 },
                { "name": "Istanbul", "coordinates": [28.9784, 41.0082], "population": 13287000 },
            ],
            minLat: -6.1751,
            maxLat: 50.7558,
            minLong: 37.6173,
            maxLong: 180.6917
        }

        var centerLat = (data.minLat + data.maxLat) / 2;
        var distanceLat = data.maxLat - data.minLat;
        var bufferLat = distanceLat * 0.18;
        var centerLong = (data.minLong + data.maxLong) / 2;
        var distanceLong = data.maxLong - data.minLong;
        var bufferLong = distanceLong * 0.15;

        return (
            <div>
                <Map
                    className="markercluster-map"
                    center={center} zoom={1} maxZoom={3} minZoom={1}
                    style={mapStyle}
                    bounds={[
                        [data.minLat - bufferLat, data.minLong - bufferLong],
                        [data.maxLat + bufferLat, data.maxLong + bufferLong]
                    ]}
                >
                    <TileLayer
                        attribution='&amp;copy <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />

                    <MarkerClusterGroup>

                        {countrySummaryValues.map((c) => {
                            console.log(c.key)
                            console.log(c.key + ": " + c.value)
                            return (
                                <CircleMarker
                                    key={c.key}
                                    center={[c.otherValues.country.location["lat"], c.otherValues.country.location["lon"]]}
                                    radius={20}
                                    fillOpacity={0.5}
                                    stroke={false}
                                >
                                    <Tooltip key={c.key} direction="top" offset={[-8, -2]} opacity={1}>
                                        <span>{c.key + ": " + c.value}</span>
                                    </Tooltip>
                                </CircleMarker>
                            )
                        }
                        )}


                    </MarkerClusterGroup>
                </Map>
            </div>
        );
    }
}

export default HotspotMapView;