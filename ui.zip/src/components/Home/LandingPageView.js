import React from 'react';
import { inject, observer } from 'mobx-react';
import { withRouter, Link } from 'react-router-dom'
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

import {
    GridList,
    GridListTile,
    GridListTileBar,
    IconButton,
} from '@material-ui/core';

import {
    StarBorder as StarBorderIcon,
} from '@material-ui/icons';

import HotspotMapView from './HotspotMapView';
import SearchField from '../Article/SearchField';

const styles = theme => ({
    root: {

        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-around',
        overflow: 'hidden',
        marginTop: '20px',
        backgroundColor: theme.palette.background.paper,
    },
    gridList: {
        flexWrap: 'wrap',
        // Promote the list into his own layer on Chrome. This cost memory but helps keeping high FPS.
        transform: 'translateZ(0)',
    },
    titleBar: {
        background:
            'linear-gradient(to bottom, rgba(0,0,0,0.7) 0%, ' +
            'rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)',
    },
    footerBar: {
        background:
            'linear-gradient(to top, rgba(0,0,0,0.7) 0%, ' +
            'rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)',
    },
    icon: {
        color: 'white',
    },
    gridListTile: {
        cursor: 'pointer',
    }
});

@inject('landingPageStore', 'articlesStore')
@withRouter
@observer
class LandingPageView extends React.Component {

    componentWillMount() {
        this.props.landingPageStore.loadCountryMapSummary();
    }

    componentDidUpdate(previousProps) {

    }

    searchArticles = (country) => {
        this.props.articlesStore.resetPagination();
        const { history } = this.props;
        history.push(`/search`);
    }


    render() {
        const { classes } = this.props;
        const { countrySummaryValues } = this.props.landingPageStore;

        return (
            <React.Fragment>
                <Link to={`/search`}>
                    <SearchField />
                </Link>
                <div>
                  <HotspotMapView countrySummary={countrySummaryValues}/>
                </div>
                <div className={classes.root}>
                   
                </div>
            </React.Fragment >
        );
    }
};

LandingPageView.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(LandingPageView);
