import React from 'react';

import AdSense from "react-adsense";
import {
  Advertisement,
} from "semantic-ui-react";


const AdSenseAdv = props => {
  return (
    <Advertisement unit={props.unit} test="My adv" {...props}>
      {/* <AdSense.Google
        client="ca-pub-4591861188995436"
        slot="4640466102"
        responsive="true"
      /> */}
    </Advertisement>
  );
}

export default AdSenseAdv;