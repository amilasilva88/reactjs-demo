import React from 'react';
import { inject, observer } from 'mobx-react';

const FAVORITED_CLASS = 'btn btn-lg btn-primary btn-follow';
const NOT_FAVORITED_CLASS = 'btn btn-lg btn-outline-primary btn-follow';


@inject('userStore', 'followStore')
@observer
class FollowButton extends React.Component {

    componentWillMount() {
        const { follower } = this.props.profile;
        this.props.followStore.setFollowing(follower);
    }

    componentDidMount() {

    }

    handleFollow = (ev) => {
        ev.preventDefault();

        const { following } = this.props.followStore;
        const { email } = this.props.profile;
        const currentUser = this.props.userStore.currentUser;

        const user = {
            userId: currentUser['userId'],
            email: currentUser['email'],
        }

        if (following) {
            this.props.userStore.unfollow(email, user);
            this.props.followStore.toggleFollow();
        } else {
            this.props.userStore.follow(email, user);
            this.props.followStore.toggleFollow();
        }

    };

    render() {
        const { following } = this.props.followStore;

        let styleName = following ? NOT_FAVORITED_CLASS : FAVORITED_CLASS;
        let buttonTxt = following ? 'Unfollow' : 'Follow';

        if (this.props.isLoggedInUser)
            return "";

        return (
            <button className={styleName} onClick={this.handleFollow} >
                {buttonTxt}
            </button >
        );
    }
}

export default FollowButton;