import React from 'react'
import { Form } from 'semantic-ui-react'


const CityDropdown = (props) => (
  <Form.Dropdown
    placeholder='Select city/cities'
    fluid
    search
    selection 
    options={props.cities}
    {...props}
  />
)

export default CityDropdown;