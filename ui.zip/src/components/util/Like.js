import React from 'react';
import { inject, observer } from 'mobx-react';
import { Button, Icon } from 'semantic-ui-react';


@inject('feedbackStore')
@observer
class Like extends React.Component {

    enityId = "";
    entityType = "";

    componentWillMount() {
        this.entityType = this.props.entityType;
        this.enityId = this.props.enityId;
        if (this.enityId) {
            this.props.feedbackStore.loadFeedback(this.entityType, this.enityId);
        }
    }

    componentDidMount() {

    }

    handleLike = () => {
        this.props.feedbackStore.updateFeedback(this.entityType, this.enityId, 'likeCount', { isLike: true });
    }

    render() {
        let entityType = this.props.entityType;
        let enityId = this.props.enityId;

        if (this.enityId !== enityId) {
            this.props.feedbackStore.loadFeedback(entityType, enityId);
            this.entityType = entityType;
            this.enityId = enityId;
        }

        const feedback = this.props.feedbackStore.getFeedback(entityType, enityId);
        if (!feedback) return "";

        return (
            <Icon name='heart outline' link onClick={this.handleLike}>
                &nbsp;{feedback.likeCount}
            </Icon>
        );
    }
}

export default Like;