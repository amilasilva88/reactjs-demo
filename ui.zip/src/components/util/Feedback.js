import React from 'react';
import { inject, observer } from 'mobx-react';
import { Button } from 'semantic-ui-react';


@inject('feedbackStore')
@observer
class Feedback extends React.Component {

    enityId = "";
    entityType = "";

    componentWillMount() {
        this.entityType = this.props.entityType;
        this.enityId = this.props.enityId;
        if (this.enityId) {
            this.props.feedbackStore.loadFeedback(this.entityType, this.enityId);
        }
    }

    componentDidMount() {

    }

    componentWillUnmount() {
        this.props.feedbackStore.reset();
    }

    handleHappy = () => {
        this.props.feedbackStore.updateFeedback(this.entityType, this.enityId, 'happyCount');
    }

    handleFriendly = () => {
        this.props.feedbackStore.updateFeedback(this.entityType, this.enityId, 'friendlyCount');
    }

    handleSad = () => {
        this.props.feedbackStore.updateFeedback(this.entityType, this.enityId, 'sadCount');
    }

    render() {
        let entityType = this.props.entityType;
        let enityId = this.props.enityId;

        if (this.enityId !== enityId) {
            this.props.feedbackStore.loadFeedback(entityType, enityId);
            this.entityType = entityType;
            this.enityId = enityId;
        }

        const feedback = this.props.feedbackStore.getFeedback(entityType, enityId);
        if (!feedback) return "";

        return (
            <span className="feedback-widget">
                <Button
                    content=''
                    icon={<i className="far fa-grin fa-lg" />}
                    label={{ as: 'a', basic: true, content: feedback.happyCount }}
                    labelPosition='right'
                    onClick={this.handleHappy}
                />
                <Button
                    content=''
                    icon={<i className="far fa-meh fa-lg" />}
                    label={{ as: 'a', basic: true, content: feedback.friendlyCount }}
                    labelPosition='right'
                    onClick={this.handleFriendly}
                />
                <Button
                    content=''
                    icon={<i className="far fa-frown-open fa-lg" />}
                    label={{ as: 'a', basic: true, content: feedback.sadCount }}
                    labelPosition='right'
                    onClick={this.handleSad}
                />

            </span >
        );
    }
}

export default Feedback;