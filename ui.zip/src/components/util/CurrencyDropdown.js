import React from 'react'
import { Dropdown, Form } from 'semantic-ui-react'
import dataLists from '../../utils/DataLists';



const loadCurrencies = (selectedcountries) => {
  let options = [];
  selectedcountries.forEach(c => {
    let cd = dataLists.currencyList[c];
    let currency = {
      key: c,
      value: cd,
      text: cd
    }
    options.push(currency);
  })
  return options;
}

const CurrencyDropdown = (props) => {
  let currencyOptions = loadCurrencies(props.selectedcountries);

  if (currencyOptions.length == 0 && !props.value) {
    let currency = {
      key: props.value,
      value: props.value,
      text: props.value
    }
    currencyOptions.push(currency);
  }
  // return <Dropdown search selection multiple allowAdditions options={currencyOptions} />
  return <Form.Select {...props} options={currencyOptions} />
}

export default CurrencyDropdown;