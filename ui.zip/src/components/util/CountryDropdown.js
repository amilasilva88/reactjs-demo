import React from 'react'
import { Form } from 'semantic-ui-react'


const CountryDropdown = (props) => (
  <Form.Dropdown
    placeholder='Select Country'
    fluid
    search
    selection
    options={props.countries}
    {...props}
  />
)

export default CountryDropdown;