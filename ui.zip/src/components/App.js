import Header from './Header';
import React from 'react';
import { Switch, Route, withRouter } from 'react-router-dom';
import { inject, observer } from 'mobx-react';

import Article from './Article';
import NewArticle from './Article/ArticleEditorPg1';
import ArticleDelivery from './Article/ArticleDeliveryEditor';
import ArticleForRequest from './Article/ArticleForRequestEditor';
import Editor from './Article/ArticleDeliveryEditor';
import Home from './Home';
import SearchPage from './Home/SearchPage';
import Login from './Login';
import Profile from './profile/Profile';
import Register from './profile/Register';
import ProfileEditor from './profile/ProfileEditor';


@inject('userStore', 'commonStore')
@withRouter
@observer
export default class App extends React.Component {

  componentWillMount() {
    if (this.props.commonStore.token) {
      this.props.userStore.pullUser()
        .finally(() => this.props.commonStore.setAppLoaded());
    } else {
      this.props.commonStore.setAppLoaded();
    }
  }

  render() {
    if (this.props.commonStore.appLoaded) {
      return (
        <div>
          <Header
            appName={this.props.appName}
            currentUser={this.props.currentUser}
          />
          <Switch>
            <Route path="/login" component={Login} />
            <Route path="/register" component={Register} />
            <Route path="/article/new" component={NewArticle} />
            <Route path="/article/new-delivery" component={ArticleDelivery} />
            <Route path="/article/new-request" component={ArticleForRequest} />
            <Route path="/article/edit/:slug" component={Editor} />
            <Route path="/article/:id" component={Article} />
            <Route path="/@:userId" component={Profile} />
            <Route path="/profile/edit/@:userId" component={ProfileEditor} />
            {/* <Route path="/@:username" component={Profile} />
            <Route path="/@:username/favorites" component={Profile} /> */}
            <Route path="/search" component={SearchPage} />
            <Route path="/" component={Home} />
          </Switch>
        </div>
      );
    }
    return (
      <Header />
    );
  }
}
