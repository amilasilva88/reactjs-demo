import { observable, action, computed } from 'mobx';
import agent from '../agent';

class FeedbackStore {

  @observable feedback = {};
  @observable feedbackRegistry = observable.map();
  @observable isLoading = false;
  tempFeedback = {};
  @observable lastClickedType = '';


  @action reset() {
    this.lastClickedType = '';
    this.tempFeedback = {
      likeCount: 0,
      friendlyCount: 0,
      happyCount: 0,
      sadCount: 0
    };

    this.feedback = {
      likeCount: 0,
      friendlyCount: 0,
      happyCount: 0,
      sadCount: 0
    };
    this.feedbackRegistry.clear();
  }

  getFeedback(entityType, mainId) {
    let key = entityType + '_' + mainId;
    const feedback = this.feedbackRegistry.get(key);
    return feedback;
  }


  @action loadFeedback(entityType, mainId) {
    this.isLoading = true;
    let key = entityType + '_' + mainId;

    switch (entityType) {
      case 'article': {
        return agent.Feedback.forArticle(mainId)
          .then(action(({ content }) => {
            this.feedback = content;
            this.feedbackRegistry.set(key, content)
          }))
          .finally(action(() => { this.isLoading = false; }));
      }
      case 'user': {
        return agent.Feedback.forUser(mainId)
          .then(action(({ content }) => {
            this.feedback = content;
            this.feedbackRegistry.set(key, content)
          }))
          .finally(action(() => { this.isLoading = false; }));
      }
    }
  }

  @action updateFeedback(entityType, enityId, mode,  { isLike = false } = {}) {
    this.isLoading = true;
    let key = entityType + '_' + enityId;

    if (!this.lastClickedType) {
      this.lastClickedType = mode;
    } else if (this.lastClickedType === mode && !isLike) {
      return;
    };

    this.feedback = this.feedbackRegistry.get(key)
    this.feedback[mode] = this.feedback[mode] + 1;
    this.tempFeedback[mode] = 1;

    this.feedbackRegistry.set(key, this.feedback)

    agent.Feedback.save(this.feedback['id'], this.tempFeedback)
      .catch(action((err) => {
        this.errors = err.response && err.response.body && err.response.body.errors; throw err;
      }))
      .finally(action(() => { this.isLoading = false; }));

    this.lastClickedType = mode;
  }
}

export default new FeedbackStore();
