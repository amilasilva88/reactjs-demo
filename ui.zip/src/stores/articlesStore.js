import { observable, action, computed } from 'mobx';
import agent from '../agent';


export class ArticlesStore {

  @observable pageLimit = 12;
  @observable isLoading = false;
  @observable totalPagesCount = 0;
  @observable totalElements = 0;
  @observable pageOffset = 0;
  @observable pageNo = 0;
  @observable articlesPreviewRegistry = new Map();
  @observable articlesRegistry = new Map();
  @observable predicate = {};

  @observable article = {};
  @observable viewCounter = 0;

  @computed get articles() {
    return [...this.articlesPreviewRegistry.values()];
  };

  @action resetPagination() {
    this.totalPagesCount = 0;
    this.pageOffset = 0;
    this.pageNo = 0;
    this.totalElements = 0;
  }

  @action resetPredicate() {
    this.predicate = {};
    this.pageOffset = 0;
    this.pageNo = 0;
    this.totalElements = 0;
  }

  @computed get currentArticle() {
    return this.article;
  }

  getArticle(id) {
    let article = this.articlesRegistry.get(id);
    return article;
  }

  @action setPageNo(pageNo) {
    this.pageNo = pageNo;
  }

  @action setPageOffset(Offset) {
    this.pageOffset = Offset;
  }

  getArticleURL(id) {
    return agent.UI_ROOT + "#/article/" + id;
  }

  @action setPredicate(predicate) {
    if (JSON.stringify(predicate) === JSON.stringify(this.predicate)) return;
    this.resetPagination();
    this.predicate = predicate;
  }

  $req() {
    if (this.predicate.followers) return agent.Articles.feed(this.pageNo, this.pageLimit);
    if (this.predicate.favoritedBy) return agent.Articles.favoritedBy(this.predicate.favoritedBy, this.pageNo, this.pageLimit);
    // if (this.predicate.tag) return agent.Articles.byTag(this.predicate.tag, this.pageNo, this.pageLimit);
    if (this.predicate.intlFlag || this.predicate.domesticFlag ) return agent.Articles.search(this.predicate, this.pageNo, this.pageLimit);
    if (this.predicate.searchText) return agent.Articles.search(this.predicate, this.pageNo, this.pageLimit);
    if (this.predicate.isSearch) return agent.Articles.search(this.predicate, this.pageNo, this.pageLimit);
    return agent.Articles.all(this.pageNo, this.pageLimit, this.predicate);
  }

  @action loadArticles() {
    this.isLoading = true;
    return this.$req()
      .then(action(({ content, totalPages, totalElements }) => {
        this.articlesPreviewRegistry.clear();
        content.forEach(article => {
          this.articlesPreviewRegistry.set(article.id, article)
        });
        this.totalPagesCount = totalPages;
        this.totalElements = totalElements;
      }))
      .finally(action(() => { this.isLoading = false; }));
  }

  @action loadArticle(id, { acceptCached = false } = {}) {
    if (acceptCached) {
      const article = this.getArticle(id);
      if (article) return Promise.resolve(article);
    }
    this.isLoading = true;
    return agent.Articles.get(id)
      .then(action(({ content }) => {
        this.articlesRegistry.set(content.id, content);
        this.article = content;
        return content;
      }))
      .finally(action(() => { this.isLoading = false; }));
  }

  @action makeFavorite(slug) {
    const article = this.getArticle(slug);
    if (article && !article.favorited) {
      article.favorited = true;
      article.favoritesCount++;
      return agent.Articles.favorite(slug)
        .catch(action(err => {
          article.favorited = false;
          article.favoritesCount--;
          throw err;
        }));
    }
    return Promise.resolve();
  }

  @action unmakeFavorite(slug) {
    const article = this.getArticle(slug);
    if (article && article.favorited) {
      article.favorited = false;
      article.favoritesCount--;
      return agent.Articles.unfavorite(slug)
        .catch(action(err => {
          article.favorited = true;
          article.favoritesCount++;
          throw err;
        }));
    }
    return Promise.resolve();
  }

  @action createArticle(article) {
    return agent.Articles.create(article)
      .then(({ content }) => {
        this.articlesRegistry.set(content.id, content);
        return content;
      })
  }

  @action updateArticle(article) {
    return agent.Articles.update(article)
      .then((content) => {
        this.articlesRegistry.set(content.id, content);
        return content;
      })
  }

  @action deleteArticle(id) {
    this.articlesRegistry.delete(id);
    return agent.Articles.del(id)
      .catch(action(err => { this.loadArticles(); throw err; }));
  }

  @action plusOne(id) {
    return agent.ViewCounter.plusOne(id)
    .then((content) => {
      this.viewCounter = content.counter;
      return content.counter;
    })
  }

  @action viewCount(id) {
   return agent.ViewCounter.get(id)
     .then((content) => {
      this.viewCounter = content.counter;
      return content.counter;
    });
  }

}

export default new ArticlesStore();
