import { observable, action } from 'mobx';
import agent from '../agent';
import validator from '../utils/Validation';

export class CommentsStore {

  @observable isCreatingComment = false;
  @observable isLoadingComments = false;
  @observable commentsRegistry = observable.map();
  @observable comments = [];
  @observable hasErrors = false;
  @observable errors = {};

  @observable comment = {
    comment: '',
    articleId: undefined,
    profileId: undefined,
    refCommentId: '',
    userId: ''
  };

  @action setArticleSlug(articleId) {
    if (this.articleId !== articleId) {
      this.comments = [];
      this.articleId = articleId;
      this.profileId = undefined;
    }
  }

  @action reset() {
    this.comments = [];
    this.commentsRegistry.clear();
    this.errors = {};
    this.hasErrors = false;
    this.comment = {
      comment: '',
      articleId: undefined,
      profileId: undefined,
      refCommentId: '',
      userId: ''
    }
  }

  getComments(entityType, entityId) {
    let key = entityType + '_' + entityId;
    const comments = this.commentsRegistry.get(key);
    return comments;
  }

  @action loadComments(entityType, entityId) {
    this.isLoadingComments = true;
    this.errors = {};
    let key = entityType + '_' + entityId;

    switch (entityType) {
      case 'article': {
        return agent.Comments.forArticle(entityId)
          .then(action(({ content }) => {
            this.comments = content;
            this.commentsRegistry.set(key, content);
          }))
          .catch(action(err => {
            this.errors = err.response && err.response.body && err.response.body.errors;
            throw err;
          }))
          .finally(action(() => { this.isLoadingComments = false; }));
      }
      case 'user': {
        return agent.Comments.forProfile(entityId)
          .then(action(({ content }) => {
            this.comments = content;
            this.commentsRegistry.set(key, content);
          }))
          .catch(action(err => {
            this.errors = err.response && err.response.body && err.response.body.errors;
            throw err;
          }))
          .finally(action(() => { this.isLoadingComments = false; }));
      }
    }
  }

  @action validite() {
    this.hasErrors = false;
    this.errors = {};

    if (validator.isEmpty(this.comment.comment)) {
      this.errors['comment'] = true;
      this.errors['commentMSG'] = 'Invalid comment input';
      this.hasErrors = true;
    }

    return this.hasErrors;
  }

  @action createComment(entityType, entityId) {
    this.isCreatingComment = true;

    return agent.Comments.create(this.comment)
      .then(() => this.loadComments(entityType, entityId))
      .finally(action(() => { this.isCreatingComment = false; }));
  }

  @action deleteComment(entityType, entityId, commentId) {

    return agent.Comments.delete(commentId)
      .then(() => this.loadComments(entityType, entityId))
      .catch(action(err => {
        this.errors = err.response && err.response.body && err.response.body.errors;
        throw err;
      }));
  }
}

export default new CommentsStore();
