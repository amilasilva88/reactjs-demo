import { observable, action } from 'mobx';
import agent from '../agent';
import validator from '../utils/Validation';
import dataLists from '../utils/DataLists';

class UserStore {

  @observable currentUser;
  @observable loadingUser;
  @observable loadingProfilePrev;
  @observable updatingUser;
  @observable updatingUserErrors;

  @observable userProfile = {};
  @observable countries = [];

  @action loadInitialData() {
    dataLists.countryList.forEach(c => {
      let country = {
        key: c.name,
        value: c.name,
        text: c.name,
        flag: c.countryCode
      }
      this.countries.push(country);
    });
  }

  @action setFieldValue(field, value) {
    if (field.includes(".")) {
      var f = field.split(".");
      this.userProfile[f[0]][f[1]] = value;
    } else {
      this.userProfile[field] = value;
    }
  }

  @action reset() {
    this.userProfile = {};
  }

  @action updateUser(user) {
    if (user) {
      this.currentUser = user;
      this.userProfile = user;
    }
  }

  @action pullUser() {
    this.loadingUser = true;
    return agent.Auth.current()
      .then(action(({ content }) => {
        this.currentUser = content;
        this.userProfile = content;
      }))
      .finally(action(() => { this.loadingUser = false; }))
  }

  @action loadProfile(userId) {
    this.updatingUser = true;

    return agent.Profile.get(this.currentUser.userId)
      .then(action(({ content }) => { this.userProfile = content; }))
      .finally(action(() => { this.updatingUser = false; }))
  }

  @action updateProfile(user) {
    this.updatingUser = true;

    return agent.Profile.save(this.currentUser.userId, user)
      .then(action(({ content }) => {
        this.userProfile = content;
        this.currentUser = content;
      }))
      .finally(action(() => { this.updatingUser = false; }))
  }

  @action follow(username, follower) {
    this.loadingProfilePrev = true;
    return agent.Profile.follow(username, follower)
      .then(action(({ content }) => {
        this.userProfile = content;
      }))
      .finally(action(() => { this.loadingProfilePrev = false; }))
  }

  @action unfollow(username, follower) {
    this.loadingProfilePrev = true;
    return agent.Profile.unfollow(username, follower)
      .then(action(({ content }) => {
        this.userProfile = content;
      }))
      .finally(action(() => { this.loadingProfilePrev = false; }))
  }

  @action forgetUser() {
    this.currentUser = undefined;
    this.userProfile = undefined;
  }

}

export default new UserStore();
