import { observable, action, computed } from 'mobx';
import agent from '../agent';


export class LandingPageDataStore {

    @observable pageLimit = 12;
    @observable isLoading = false;
    @observable countrySummaryMap = new Map();
    @observable predicate = {};
    @observable totalElements = 0;

    @observable countrySummary = {};


    @computed get countrySummaryValues() {
        return [...this.countrySummaryMap.values()];
    };

    getCountrySummary(id) {
        let summary = this.countrySummaryMap.get(id);
        return summary;
    }

    // @action setPredicate(predicate) {
    //   if (JSON.stringify(predicate) === JSON.stringify(this.predicate)) return;
    //   this.resetPagination();
    //   this.predicate = predicate;
    // }

    // $req() {
    //   if (this.predicate.followers) return agent.Articles.feed(this.pageNo, this.pageLimit);
    //   if (this.predicate.favoritedBy) return agent.Articles.favoritedBy(this.predicate.favoritedBy, this.pageNo, this.pageLimit);
    //   // if (this.predicate.tag) return agent.Articles.byTag(this.predicate.tag, this.pageNo, this.pageLimit);
    //   if (this.predicate.intlFlag || this.predicate.domesticFlag ) return agent.Articles.search(this.predicate, this.pageNo, this.pageLimit);
    //   if (this.predicate.searchText) return agent.Articles.search(this.predicate, this.pageNo, this.pageLimit);
    //   return agent.Articles.all(this.pageNo, this.pageLimit, this.predicate);
    // }

    @action loadCountrySummary() {
        this.isLoading = true;
        return agent.LandingSummary.getCountrySummary()
            .then(action(({ buckets, totalElements }) => {
                this.countrySummaryMap.clear();
                buckets.forEach(bucket => {
                    this.countrySummaryMap.set(bucket.key, bucket)
                });
                this.totalElements = totalElements;
            }))
            .finally(action(() => { this.isLoading = false; }));
    }

    @action loadCountryMapSummary() {
        console.log("::::::::::::::: Load country map 1");
        this.isLoading = true;
        return agent.LandingSummary.getCountryMapSummary()
            .then(action(({ buckets, totalElements }) => {
              console.log("::::::::::::::: Load country map 1.1");
                this.countrySummaryMap.clear();
                console.log("::::::::::::::: Load country map 1.2");
                buckets.forEach(bucket => {
                    this.countrySummaryMap.set(bucket.key, bucket)
                });
                this.totalElements = totalElements;
                console.log("::::::::::::::: Load country map 1.3" + totalElements);
                console.log(this.countrySummaryMap);
                console.log(this.totalElements);
            }))
            .finally(action(() => { this.isLoading = false; }));
    }

    // @action loadArticle(id, { acceptCached = false } = {}) {
    //   if (acceptCached) {
    //     const article = this.getArticle(id);
    //     if (article) return Promise.resolve(article);
    //   }
    //   this.isLoading = true;
    //   return agent.Articles.get(id)
    //     .then(action(({ content }) => {
    //       this.articlesRegistry.set(content.id, content);
    //       this.article = content;
    //       return content;
    //     }))
    //     .finally(action(() => { this.isLoading = false; }));
    // }

    @action makeFavorite(slug) {
        const article = this.getArticle(slug);
        if (article && !article.favorited) {
            article.favorited = true;
            article.favoritesCount++;
            return agent.Articles.favorite(slug)
                .catch(action(err => {
                    article.favorited = false;
                    article.favoritesCount--;
                    throw err;
                }));
        }
        return Promise.resolve();
    }

    @action unmakeFavorite(slug) {
        const article = this.getArticle(slug);
        if (article && article.favorited) {
            article.favorited = false;
            article.favoritesCount--;
            return agent.Articles.unfavorite(slug)
                .catch(action(err => {
                    article.favorited = true;
                    article.favoritesCount++;
                    throw err;
                }));
        }
        return Promise.resolve();
    }
}

export default new LandingPageDataStore();