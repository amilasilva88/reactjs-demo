import { observable, action, computed } from 'mobx';

import validator from '../utils/Validation';
import agent from '../agent';

class OfferRequestStore {

  @observable inProgress = false;
  @observable articleId = undefined;
  @observable hasErrors = false;
  @observable errors = {};

  @observable offers = [];

  @observable offerDialogOpen = false;

  @observable acceptedOfferDetails = undefined;

  @observable offer = {
    offerValue: 0.0,
    comment: '',
    articleId: undefined,
    userId: undefined,
    status: 'ACTIVE',
    acceptedBy: undefined
  };

  @action setOfferDialogOpen(isOpen) {
    this.offerDialogOpen = isOpen;
  }

  @action setArticleSlug(articleId) {
    if (articleId) {
      this.articleId = articleId;
    }
  }

  @action currentArticleId(articleId) {
    this.articleId = articleId;
    this.offer.articleId = articleId;
  }

  @action loadOfferRequestByArticle(articleId) {

    return agent.Offers.forArticle(articleId)
      .then(action(({ content, totalPages, totalElements }) => {
        this.offers = content;
        this.totalPagesCount = totalPages;
        this.totalElements = totalElements;
      }))
      .finally(action(() => { this.isLoading = false; }));
  }

  @action loadUserOfferRequestsForArticle(articleId) {
    return agent.Offers.userOffersForArticle(articleId)
      .then(action(({ content, totalPages, totalElements }) => {
        this.offers = content;
        this.totalPagesCount = totalPages;
        this.totalElements = totalElements;
      }))
      .finally(action(() => { this.isLoading = false; }));
  }

  @action loadOfferRequestByUser(userId) {

    //   this.selectedcountries[0] = country;

    //   return agent.CountryData.getCities(country)
    //     .then(action(({ content }) => {
    //       this.pickupCities = [];
    //       content.forEach(c => {
    //         let city = {
    //           key: c.id,
    //           value: c.city,
    //           text: c.city
    //         }
    //         this.pickupCities.push(city);
    //       });
    //     }))
    //     .finally(action(() => { this.inProgress = false; }));
  }

  @action findAcceptedOffer(articleId) {
    this.acceptedOfferDetails = undefined;

    return agent.Offers.findAcceptedOffer(articleId)
      .then(action(({ content }) => {
        this.acceptedOfferDetails = content;
        return content;
      }))
      .catch(action((err) => {
        this.errors = err.response && err.response.body && err.response.body.errors; throw err;
      }))
      .finally(action(() => { this.isLoading = false; }));
  }

  @action acceptOffer(offerId) {
    return agent.Offers.acceptOffer(offerId)
      .then(action(({ content }) => {
        return content;
      }))
      .finally(action(() => { this.isLoading = false; }));
  }

  @action confirmOffer(offerId) {
    return agent.Offers.confirmOffer(offerId)
      .then(action(({ content }) => {
        return content;
      }))
      .catch(action((err) => {
        this.errors = err.response && err.response.body && err.response.body.errors; throw err;
      }))
      .finally(action(() => { this.isLoading = false; }));
  }


  @action reset() {
    this.offer = {
      offerValue: 0.0,
      comment: '',
      articleId: undefined,
      userId: undefined,
      status: 'ACTIVE',
      acceptedBy: undefined
    }
    this.offerValue = 0.0;
    this.comment = '';
    this.acceptedBy = undefined;
    this.errors = {};
    this.hasErrors = false;
  }

  @action setFieldValue(field, value) {
    if (field.includes(".")) {
      var f = field.split(".");
      this.offer[f[0]][f[1]] = value;
    } else {
      this.offer[field] = value;
    }
  }

  @action getFieldValue(field) {
    return (field.includes(".")) ? () => {
      var f = field.split(".");
      return this.offer[f[0]][f[1]];
    } :
      this.offer[field];
  }

  @action validite() {
    this.hasErrors = false;
    this.errors = {};

    if (validator.isEmpty(this.offer.comment)) {
      this.errors['comment'] = true;
      this.errors['commentMSG'] = 'Invalid comment input';
      this.hasErrors = true;
    }

    if (validator.isEmpty(this.offer.offerValue)) {
      this.errors['offerValue'] = true;
      this.errors['offerValueMSG'] = 'Invalid Offer value';
      this.hasErrors = true;
    }

    return this.hasErrors;
  }

  @action submitOffer() {
    this.inProgress = true;

    return agent.Offers.create(this.offer)
      .then(({ content }) => {
        return content;
      })
      .catch(action((err) => {
        this.errors = err.response && err.response.body && err.response.body.errors; throw err;
      }))
      .finally(action(() => {
        this.loadUserOfferRequestsForArticle(this.articleId);
        this.reset();
        this.inProgress = false;
      }));
  }

  @computed get articleOffers() {
    return this.offers;
  };


  @action validateOffer() {
    this.hasErrors = false;
    this.errors = {};

    let emptyChecks = ["offerValue", "comment"];
    let numberCheck = ["offerValue"];
    let priceCheck = ["offerValue"];

    this.hasErrors = this.validate(emptyChecks, numberCheck, priceCheck);
    return this.hasErrors;
  }

  validate = (emptyChecks, numberCheck, priceCheck) => {
    emptyChecks.forEach(f => {
      if (validator.isEmpty(this.offer[f])) {
        this.errors[f] = true;
        this.errors[f + 'Msg'] = this.capitalize(f) + ' is required';
        this.hasErrors = true;
      }
    });
    numberCheck.forEach(f => {
      if (this.offer[f] < 1) {
        this.errors[f] = true;
        this.errors[f + 'Msg'] = 'Invalid offer value';
        this.hasErrors = true;
      }
    });
    priceCheck.forEach(f => {
      if (!validator.validatePrice(this.offer[f])) {
        this.errors[f] = true;
        this.errors[f + 'Msg'] = 'Invalid Offer price';
        this.hasErrors = true;
      }
    })
    return this.hasErrors;
  }

  capitalize = s => {
    return (s) ?
      s.toLowerCase().replace(/\b./g, function (a) { return a.toUpperCase(); })
      : s;
  };

}

export default new OfferRequestStore();
