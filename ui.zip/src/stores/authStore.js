import { observable, action } from 'mobx';
import agent from '../agent';
import userStore from './userStore';
import commonStore from './commonStore';
import validator from '../utils/Validation';

export class AuthStore {
  @observable inProgress = false;
  @observable errors = {};
  @observable hasError = false;

  @observable values = {
    displayName: '',
    email: '',
    password: '',
  };

  @action setFieldValue(field, value) {
    if (field.includes(".")) {
      var f = field.split(".");
      this.values[f[0]][f[1]] = value;
    } else {
      this.values[field] = value;
    }
  }

  @action reset() {
    this.values.displayName = '';
    this.values.email = '';
    this.values.password = '';
    this.errors = {};
  }

  @action login() {
    this.inProgress = true;
    this.errors = {};
    return agent.Auth.login(this.values.email, this.values.password)
      // .then(({ user }) => commonStore.setToken(user.token))
      .then((resp) => commonStore.setToken(resp.token))
      .then(() => userStore.pullUser())
      .catch(action((err) => {
        let errorMsg = err.response && err.response.body && err.response.body.errors;
        this.errors['msg'] = errorMsg;
        throw err;
      }))
      .finally(action(() => { this.inProgress = false; }));
  }

  @action validate() {
    this.errors = {};

    let hasErrors = false;
    if (validator.isEmpty(this.values.displayName)) {
      this.errors['displayName'] = 'Displayname is required';
      hasErrors = true;
    }

    if (validator.validateEmail(this.values.email)) {
      this.errors['email'] = 'Invalid Email';
      hasErrors = true;
    }

    if (validator.isEmpty(this.values.password)) {
      this.errors['password'] = 'Password is required';
      hasErrors = true;
    }

    if (validator.validLength(this.values.password, 6)) {
      this.errors['password'] = 'Password must contain atleast six characters';
      hasErrors = true;
    }

    return hasErrors;
  }

  @action register() {
    this.inProgress = true;

    return agent.Auth.register(this.values.displayName, this.values.email, this.values.password)
      .then(({ content }) => {
        commonStore.setToken(content.token);
        userStore.updateUser();
      })
      .catch(action((err) => {
        this.errors = err.response && err.response.body && err.response.body.errors;
        this.hasError = true;
        throw err;
      }))
      .finally(action(() => { this.inProgress = false; }));
  }


  @action logout() {
    
    return agent.Auth.logout()
      .then((r) => {
        commonStore.setToken(undefined);
        userStore.forgetUser();
        return new Promise(res => res());
      });
  }

}

export default new AuthStore();
