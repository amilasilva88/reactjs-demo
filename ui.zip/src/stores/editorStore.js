import { observable, action } from 'mobx';
import articlesStore from './articlesStore';
import validator from '../utils/Validation';
import agent from '../agent';

class EditorStore {

  @observable inProgress = false;
  @observable articleId = undefined;
  @observable hasErrors = false;
  @observable errors = {};

  @observable countries = [];
  @observable pickupCities = [];
  @observable dropOffCities = [];
  @observable selectedcountries = new Array(2);

  @observable termsDialogOpen = false;

  @observable article = {
    serviceType: '',
    pickupAddress: {
      cities: []
    },
    dropoffAddress: {
      cities: []
    },
    senderContact: {},
    recipientContact: {},
    tags: []
  };

  @observable formTitle = 'New Order';
  @observable tagList = [];

  @action setTermsDialogOpen(isOpen) {
    this.termsDialogOpen = isOpen;
  }

  @action setArticleSlug(articleId) {
    if (articleId) {
      this.comments = [];
      this.articleId = articleId;
      this.formTitle = 'Edit Order';
    }
  }

  @action loadInitialData() {

    return agent.CountryData.get()
      .then(({ content }) => {
        this.countries = [];
        content.forEach(c => {
          let country = {
            key: c.countryCode,
            value: c.country,
            text: c.country
          }
          this.countries.push(country);
        });
      });
  }

  @action loadPickUpCities(country) {

    this.selectedcountries[0] = country;

    return agent.CountryData.getCities(country)
      .then(action(({ content }) => {
        this.pickupCities = [];
        content.forEach(c => {
          let city = {
            key: c.id,
            value: c.city,
            text: c.city
          }
          this.pickupCities.push(city);
        });
      }))
      .finally(action(() => { this.inProgress = false; }));
  }

  @action loadDropOffCities(country) {

    this.selectedcountries[1] = country;

    return agent.CountryData.getCities(country)
      .then(action(({ content }) => {
        this.dropOffCities = [];
        content.forEach(c => {
          let city = {
            key: c.id,
            value: c.city,
            text: c.city
          }
          this.dropOffCities.push(city);
        });
      }))
      .finally(action(() => { this.inProgress = false; }));
  }

  @action loadArticleData() {
    if (!this.articleId) return Promise.resolve();
    this.inProgress = true;
    articlesStore.loadArticle(this.articleId, { acceptCached: true })
      .then(action((article) => {
        if (!article) throw new Error('Can\'t load original article');
        this.article = article;
      }))
      .finally(action(() => { this.inProgress = false; }));

  }

  @action resetSelectedCountries() {
    this.selectedcountries = [];
  }


  @action reset() {
    this.article = {
      pickupAddress: {},
      dropoffAddress: {},
      senderContact: {},
      recipientContact: {},
      tags: []
    };
    this.countries = [];
    this.selectedcountries = [];
    this.tagList = [];
    this.formTitle = 'New Order';
    this.errors = {};
    this.hasErrors = false;
    this.termsDialogOpen = false;
  }

  @action setFieldValue(field, value) {
    if (field.includes(".")) {
      var f = field.split(".");
      this.article[f[0]][f[1]] = value;
    } else {
      this.article[field] = value;
    }
  }

  @action getFieldValue(field) {
    return (field.includes(".")) ? () => {
      var f = field.split(".");
      return this.article[f[0]][f[1]];
    } :
      this.article[field];
  }

  @action addTag(tag) {
    if (this.tagList.includes(tag)) return;
    this.tagList.push(tag);
  }

  @action removeTag(tag) {
    this.tagList = this.tagList.filter(t => t !== tag);
  }

  @action submit() {
    this.inProgress = true;
    this.errors = {};

    return (this.articleId ? articlesStore.updateArticle(this.article) : articlesStore.createArticle(this.article))
      .catch(action((err) => {
        this.errors = err.response && err.response.body && err.response.body.errors; throw err;
      }))
      .finally(action(() => { this.inProgress = false; }));
  }

  @action validateDeliveryOrder() {

    this.hasErrors = false;
    this.errors = {};

    let emptyChecks = ["serviceMode", "serviceType", "deliveryItem", "itemDesc", "currencyCode", "price", "termsCheck"];
    let numberCheck = [];
    let addressCheck = ["pickupAddress", "dropoffAddress"];
    let addressFields = ["cities", "country"];
    let contact = ["senderContact"];
    let contactFields = ["name", "contactNo"];

    this.hasErrors = this.validate(emptyChecks, numberCheck, addressCheck, addressFields, contact, contactFields);
    return this.hasErrors;
  }

  @action validateRequestOrder() {

    this.hasErrors = false;
    this.errors = {};

    let emptyChecks = ["serviceMode", "serviceType", "deliveryItem", "itemDesc", "transportType", "termsCheck"];
    let numberCheck = ["pickupDateTime", "dropoffDateTime"];
    let addressCheck = ["pickupAddress", "dropoffAddress"];
    let addressFields = ["cities", "country"];
    let contact = ["senderContact"];
    let contactFields = ["name", "contactNo"];

    this.hasErrors = this.validate(emptyChecks, numberCheck, addressCheck, addressFields, contact, contactFields);
    return this.hasErrors;
  }

  capitalize = s => {
    return (s) ?
      s.toLowerCase().replace(/\b./g, function (a) { return a.toUpperCase(); })
      : s;
  };

  validate = (emptyChecks, numberCheck, addressCheck, addressFields, contact, contactFields) => {
    emptyChecks.forEach(f => {
      if (validator.isEmpty(this.article[f])) {
        this.errors[f] = true;
        this.errors[f + 'Msg'] = this.capitalize(f) + ' is required';
        this.hasErrors = true;
      }
    });
    let priceVal = this.article['price'];
    if (!validator.validatePrice(priceVal)) {
      this.errors['price'] = true;
      this.errors['priceMsg'] = 'Invalid price amount input';
    }
    numberCheck.forEach(f => {
      if (!validator.isNumber(this.article[f])) {
        this.errors[f] = true;
        this.errors[f + 'Msg'] = this.capitalize(f) + ' is required';
        this.hasErrors = true;
      }
    });
    if (this.article['pickupDateTime'] < new Date().getTime()) {
      this.errors['pickupDateTime'] = true;
      this.errors['pickupDateTimeMsg'] = this.capitalize('pickupDateTime') + ' is should be a future date';
      this.hasErrors = true;
    }
    if (this.article['dropoffDateTime'] < new Date().getTime()) {
      this.errors['dropoffDateTime'] = true;
      this.errors['dropoffDateTimeMsg'] = this.capitalize('dropoffDateTime') + ' is should be a future date';
      this.hasErrors = true;
    }
    if (this.article['pickupDateTime'] > this.article['dropoffDateTime']) {
      this.errors['dropoffDateTime'] = true;
      this.errors['dropoffDateTimeMsg'] = this.capitalize('dropoffDateTime') + ' is should be after Pickup date';
      this.hasErrors = true;
    }
    addressCheck.forEach(mainObjField => {
      var obj = this.article[mainObjField];
      var exit = false;
      addressFields.forEach(f => {
        if (f in obj && !exit) {
          if (validator.isEmpty(obj[f])) {
            this.errors[mainObjField + '.' + f] = true;
            this.errors[mainObjField + '.' + f + 'Msg'] = this.capitalize(mainObjField) + " " + this.capitalize(f) + ' is required';
            this.hasErrors = true;
          }
        }
        else {
          this.errors[mainObjField] = true;
          this.errors[mainObjField + 'Msg'] = this.capitalize(mainObjField) + ' is required';
          this.hasErrors = true;
          exit = true;
          return;
        }
      });
    });
    contact.forEach(mainObjField => {
      var obj = this.article[mainObjField];
      var exit = false;
      contactFields.forEach(f => {
        if (f in obj && !exit) {
          if (validator.isEmpty(obj[f])) {
            this.errors[mainObjField + '.' + f] = true;
            this.errors[mainObjField + '.' + f + 'Msg'] = this.capitalize(mainObjField) + " " + this.capitalize(f) + ' is required';
            this.hasErrors = true;
          }
        }
        else {
          this.errors[mainObjField] = true;
          this.errors[mainObjField + 'Msg'] = this.capitalize(mainObjField) + ' is required';
          this.hasErrors = true;
          exit = true;
          return;
        }
      });
    });

    return this.hasErrors;
  }
}

export default new EditorStore();
