import { observable, action, computed } from 'mobx';


class FollowStore {

  @observable isFollowing = false;

  @computed get following() {
    return this.isFollowing;
  };

  @action setFollowing(isFollowing) {
    this.isFollowing = isFollowing;
  }

  @action toggleFollow() {
    this.isFollowing = (this.isFollowing)? false : true;
  }
}

export default new FollowStore();
